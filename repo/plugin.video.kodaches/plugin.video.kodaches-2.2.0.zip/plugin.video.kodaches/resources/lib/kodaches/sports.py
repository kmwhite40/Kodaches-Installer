"""
League schedules and scores for the Sports Center. No Kodi imports.

Data: ESPN's public scoreboard JSON (site.api.espn.com), read-only schedule data, no streams.
ESPN refuses date ranges for team leagues, so each day is fetched on its own.
"""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

from .sources import SourceError, fetch_json

SCOREBOARD = "https://site.api.espn.com/apis/site/v2/sports/%s/scoreboard?dates=%s&limit=200"
LOGO = "https://a.espncdn.com/i/teamlogos/leagues/500/%s.png"

# (id, display name, ESPN path, logo). Order is the menu order.
LEAGUES = [
    ("nfl", "NFL", "football/nfl", "nfl"),
    ("ncaaf", "NCAA Football", "football/college-football", "ncaa"),
    ("nba", "NBA", "basketball/nba", "nba"),
    ("ncaab", "NCAA Basketball", "basketball/mens-college-basketball", "ncaa"),
    ("wnba", "WNBA", "basketball/wnba", "wnba"),
    ("mlb", "MLB", "baseball/mlb", "mlb"),
    ("nhl", "NHL", "hockey/nhl", "nhl"),
    ("mls", "MLS", "soccer/usa.1", None),
    ("epl", "Premier League", "soccer/eng.1", None),
    ("bundesliga", "Bundesliga", "soccer/ger.1", None),
    ("ucl", "UEFA Champions League", "soccer/uefa.champions", None),
    ("f1", "Formula 1", "racing/f1", None),
    ("nascar", "NASCAR Cup Series", "racing/nascar-premier", None),
    ("ufc", "UFC", "mma/ufc", None),
    ("pga", "PGA Tour", "golf/pga", None),
    ("atp", "ATP Tennis", "tennis/atp", None),
    ("wta", "WTA Tennis", "tennis/wta", None),
]


def league_list():
    return [{"id": lid, "name": name, "logo": LOGO % logo if logo else None} for lid, name, _p, logo in LEAGUES]


def league_path(league_id):
    return next((path for lid, _n, path, _l in LEAGUES if lid == league_id), None)


def parse_event(event):
    """One ESPN scoreboard event -> what the menus show. Tolerates golf, tennis and racing shapes."""
    status = (event.get("status") or {}).get("type") or {}
    competitions = event.get("competitions") or []
    first = competitions[0] if competitions else {}
    teams, score = [], ""
    competitors = first.get("competitors") or []
    if len(competitors) == 2 and all(c.get("team") for c in competitors):
        away = next((c for c in competitors if c.get("homeAway") == "away"), competitors[1])
        home = next((c for c in competitors if c.get("homeAway") == "home"), competitors[0])
        for c in (away, home):
            t = c["team"]
            teams.append({"name": t.get("displayName") or "", "short": t.get("shortDisplayName") or t.get("name") or "",
                          "abbreviation": t.get("abbreviation") or "", "logo": t.get("logo")})
        if status.get("state") in ("in", "post"):
            score = "%s %s - %s %s" % (away["team"].get("abbreviation", ""), away.get("score", ""),
                                       home.get("score", ""), home["team"].get("abbreviation", ""))
    broadcasts = []
    for b in first.get("broadcasts") or []:
        broadcasts += [n for n in b.get("names") or [] if n not in broadcasts]
    return {
        "id": str(event.get("id", "")),
        "name": event.get("name") or event.get("shortName") or "",
        "short": event.get("shortName") or event.get("name") or "",
        "start": event.get("date"),
        "state": status.get("state") or "pre",          # pre / in / post
        "status_text": status.get("shortDetail") or status.get("detail") or status.get("description") or "",
        "teams": teams,
        "score": score,
        "venue": (first.get("venue") or {}).get("fullName") or "",
        "broadcast": ", ".join(broadcasts),
        "logo": teams[1]["logo"] if teams else None,
    }


def parse_scoreboard(data):
    events = [parse_event(e) for e in data.get("events") or []]
    order = {"in": 0, "pre": 1, "post": 2}
    return sorted(events, key=lambda e: (order.get(e["state"], 3), e["start"] or ""))


def schedule(league_id, today=None, days_back=1, days_ahead=6):
    """Games from yesterday to a week ahead, live first. Days that fail are skipped."""
    path = league_path(league_id)
    if not path:
        raise SourceError("unknown league %s" % league_id)
    today = today or datetime.now(timezone.utc)
    days = [today + timedelta(days=d) for d in range(-days_back, days_ahead + 1)]

    def day(when):
        try:
            return fetch_json(SCOREBOARD % (path, when.strftime("%Y%m%d")), timeout=15).get("events") or []
        except SourceError:
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(day, days))
    if all(r is None for r in results):
        raise SourceError("schedule unavailable for %s" % league_id)
    raw = {}
    for events in results:
        for event in events or []:
            raw.setdefault(str(event.get("id")), event)
    return parse_scoreboard({"events": list(raw.values())})
