"""
Presentation presets.

Each preset re-creates the *idea* of one of the third-party builds Kodaches replaces
(see docs/PROVENANCE.md) using only Kodi's own settings and skins from the official
Kodi repository. Nothing from those builds is copied. A preset:

  - switches to its skin (installing it from the official repo first, which Kodi
    asks the viewer to confirm),
  - sets a few core Kodi settings through JSON-RPC,
  - adds Kodaches shortcuts to Kodi Favourites, which every skin shows on Home.

apply() takes the JSON-RPC and builtin callables as arguments so tests can record calls.
"""

PLUGIN = "plugin://plugin.video.kodaches/"

# Kodi settings shared by every preset. Ids are checked against a real Kodi in tests/integration.
COMMON = {
    "lookandfeel.enablerssfeeds": False,
    "filelists.showparentdiritems": False,
    "videoplayer.adjustrefreshrate": 2,   # "on start/stop": matches 24p/50/60 Hz content on TVs
}
# Small video cache for 1 GB Fire TV sticks; Kodi's default (20 MB x 4) can exhaust them on 4K streams.
LOW_MEMORY = {"filecache.memorysize": 20, "filecache.readfactor": 300}
# Bigger buffer for 2 GB+ devices (Google TV, Shield). Kodi uses about three times this much memory.
ROOMY = {"filecache.memorysize": 64, "filecache.readfactor": 400}

SHORTCUTS = {
    "live": (30101, "live"),
    "german": (30110, "section&key=german"),
    "us": (30111, "section&key=us"),
    "local": (30112, "section&key=local"),
    "sports": (30104, "sports"),
    "news": (30114, "section&key=news"),
    "movies": (30105, "movies"),
    "fast": (30118, "section&key=fast"),
    "favorites": (30108, "favorites"),
    "search": (30107, "search"),
}

PRESETS = {
    # The Kodaches build: its own skin (Estuary-based) with Kodaches home menu and rows.
    "kodaches": {"label": 30408, "skin": "skin.kodaches", "inspired": "Kodaches build",
                 "settings": ROOMY, "shortcuts": ["live", "sports", "movies", "favorites"]},
    # Diggz Xenon: cinematic home, artwork-led widgets, discovery rows.
    "cinematic": {"label": 30401, "skin": "skin.aeon.nox.silvo", "inspired": "Diggz Xenon",
                  "settings": ROOMY, "shortcuts": ["live", "movies", "sports", "fast", "search"]},
    # Doomzday (small build): plain, fast menus, nothing loading in the background.
    "performance": {"label": 30402, "skin": "skin.estuary", "inspired": "Doomzday",
                    "settings": LOW_MEMORY, "shortcuts": ["live", "german", "us", "search"]},
    # No Limits Magic: premium look with rich artwork.
    "premium": {"label": 30403, "skin": "skin.copacetic", "inspired": "No Limits Magic",
                "settings": ROOMY, "shortcuts": ["favorites", "live", "movies", "sports", "fast"]},
    # Green Monster: every section, middle-of-the-road resources.
    "balanced": {"label": 30404, "skin": "skin.estuary", "inspired": "Green Monster",
                 "settings": {}, "shortcuts": ["favorites", "live", "german", "us", "local", "sports", "movies", "search"]},
    # Coalition / Cosmo: clean, few choices, remote-first.
    "minimal": {"label": 30405, "skin": "skin.amber", "inspired": "Coalition / Cosmo",
                "settings": LOW_MEMORY, "shortcuts": ["live", "movies", "favorites"]},
    # Transcendent: sports first.
    "sports": {"label": 30406, "skin": "skin.estuary", "inspired": "Transcendent",
               "settings": {}, "shortcuts": ["sports", "live", "local", "us", "favorites"]},
    # Breezz Lite / Misfit Mods Lite: big targets for TV remotes, light on Fire TV.
    "smarttv": {"label": 30407, "skin": "skin.ftv", "inspired": "Breezz Lite / Misfit Mods Lite",
                "settings": LOW_MEMORY, "shortcuts": ["live", "sports", "movies", "news", "search"]},
}
PRESET_KEYS = ["kodaches", "balanced", "cinematic", "performance", "premium", "minimal", "sports", "smarttv"]
BUILT_IN_SKINS = ("skin.estuary", "skin.estouchy")


def shortcut_path(key):
    return PLUGIN + "?mode=" + SHORTCUTS[key][1]


def plan(key):
    """The JSON-RPC calls a preset makes, in order (without the skin install/switch)."""
    preset = PRESETS[key]
    calls = []
    for setting, value in list(COMMON.items()) + list(preset["settings"].items()):
        calls.append(("Settings.SetSettingValue", {"setting": setting, "value": value}))
    return calls


def apply(key, rpc, builtin, label, skin_installed, wait_for_skin):
    """
    rpc(method, params) -> result; builtin(command); label(string_id) -> text;
    skin_installed(addon_id) -> bool; wait_for_skin(addon_id) -> bool (False if the viewer declined).
    Returns a list of (step, ok, detail) for the result dialog.
    """
    preset = PRESETS[key]
    report = []
    for method, params in plan(key):
        try:
            rpc(method, params)
            report.append((params["setting"], True, str(params["value"])))
        except Exception as exc:  # an unknown setting on an older Kodi must not stop the rest
            report.append((params["setting"], False, str(exc)))

    existing = {(f.get("title"), f.get("path") or f.get("windowparameter"))
                for f in (rpc("Favourites.GetFavourites", {"properties": ["path", "windowparameter"]}) or {})
                .get("favourites") or []}
    for sc in preset["shortcuts"]:
        title = "Kodaches: " + label(SHORTCUTS[sc][0])
        path = shortcut_path(sc)
        if (title, path) in existing:
            continue
        try:
            rpc("Favourites.AddFavourite", {"title": title, "type": "window", "window": "videos",
                                            "windowparameter": path,
                                            "thumbnail": "special://home/addons/plugin.video.kodaches/resources/icon.png"})
            report.append(("favourite", True, title))
        except Exception as exc:
            report.append(("favourite", False, "%s: %s" % (title, exc)))

    skin = preset["skin"]
    if skin not in BUILT_IN_SKINS and not skin_installed(skin):
        builtin("InstallAddon(%s)" % skin)  # official repo; Kodi asks the viewer to confirm
        if not wait_for_skin(skin):
            report.append(("skin", False, "%s not installed; kept the current skin" % skin))
            return report
    try:
        rpc("Settings.SetSettingValue", {"setting": "lookandfeel.skin", "value": skin})
        report.append(("skin", True, skin))
    except Exception as exc:
        report.append(("skin", False, "%s: %s" % (skin, exc)))
    return report
