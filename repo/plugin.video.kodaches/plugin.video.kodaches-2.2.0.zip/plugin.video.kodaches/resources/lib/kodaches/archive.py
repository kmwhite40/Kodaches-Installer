"""
Free classic films: public-domain feature films from the Internet Archive (collection
"feature_films"), searched through archive.org's public API and streamed from archive.org.
No Kodi imports.
"""

import html
import re
from urllib.parse import quote, urlencode

from .sources import SourceError, fetch_json

SEARCH_URL = "https://archive.org/advancedsearch.php?"
METADATA_URL = "https://archive.org/metadata/%s"
COLLECTION = "feature_films"
IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9._-]{1,120}$")
SORTS = {"popular": "downloads desc", "newest": "year desc", "title": "titleSorter asc"}
# MP4/H.264 first: plays everywhere without transcoding.
VIDEO_FORMATS = ["h.264", "h.264 HD", "MPEG4", "512Kb MPEG4", "h.264 IA"]


def _clean(text):
    if isinstance(text, list):
        text = " ".join(str(t) for t in text)
    text = re.sub(r"<[^>]+>", " ", html.unescape(str(text or "")))
    return re.sub(r"\s+", " ", text).strip()


def _seconds(length):
    try:
        if isinstance(length, str) and ":" in length:
            total = 0.0
            for part in length.split(":"):
                total = total * 60 + float(part)
            return int(total)
        return int(float(length))
    except (TypeError, ValueError):
        return 0


def _year(doc):
    raw = doc.get("year") or str(doc.get("date") or "")[:4]
    try:
        year = int(str(raw)[:4])
        return year if 1880 < year < 2100 else None
    except ValueError:
        return None


def summarize(doc):
    identifier = doc["identifier"]
    subjects = doc.get("subject") or []
    if isinstance(subjects, str):
        subjects = [s.strip() for s in subjects.split(";")]
    return {"id": identifier, "title": _clean(doc.get("title")) or identifier, "year": _year(doc),
            "overview": _clean(doc.get("description"))[:600],
            "genres": [s for s in subjects if s and len(s) < 30][:3],
            "poster": "https://archive.org/services/img/%s" % identifier,
            "runtime": _seconds(doc.get("runtime"))}


def browse(start=0, limit=40, query=None, sort="popular"):
    q = 'collection:(%s) AND mediatype:(movies) AND format:("h.264" OR "MPEG4" OR "512Kb MPEG4")' % COLLECTION
    if query:
        words = re.sub(r"[^\w\s]", " ", query).split()
        if words:
            q += " AND title:(" + " AND ".join(words[:6]) + ")"
    params = [("q", q), ("rows", str(limit)), ("page", str(start // limit + 1)), ("output", "json"),
              ("sort[]", SORTS.get(sort, SORTS["popular"]))]
    params += [("fl[]", f) for f in ("identifier", "title", "year", "date", "description", "subject", "runtime")]
    response = fetch_json(SEARCH_URL + urlencode(params)).get("response", {})
    items, seen = [], set()
    for doc in response.get("docs", []):
        if not IDENTIFIER_RE.match(doc.get("identifier", "")):
            continue
        item = summarize(doc)
        key = (re.sub(r"[^a-z0-9]", "", item["title"].lower()), item["year"])
        if key not in seen:  # the Archive often holds several uploads of one film
            seen.add(key)
            items.append(item)
    return {"items": items, "total": response.get("numFound", 0)}


def stream(identifier):
    """The film's best MP4 address, or SourceError."""
    if not IDENTIFIER_RE.match(identifier):
        raise SourceError("bad identifier")
    data = fetch_json(METADATA_URL % identifier)
    meta = data.get("metadata") or {}
    collections = meta.get("collection") if isinstance(meta.get("collection"), list) else [meta.get("collection")]
    if COLLECTION not in collections:
        raise SourceError("not a public-domain feature film")
    files = data.get("files") or []
    for fmt in VIDEO_FORMATS:
        video = next((f for f in files if f.get("format") == fmt and f.get("name", "").lower().endswith(".mp4")), None)
        if video:
            break
    else:
        video = next((f for f in files if f.get("name", "").lower().endswith(".mp4")), None)
    if not video:
        raise SourceError("no playable video file")
    return "https://archive.org/download/%s/%s" % (identifier, quote(video["name"]))
