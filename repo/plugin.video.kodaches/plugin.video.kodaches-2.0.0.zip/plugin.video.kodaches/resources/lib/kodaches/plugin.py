"""
Kodaches menus and playback. Every folder is one invocation: plugin://plugin.video.kodaches/?mode=...

Standalone: channels come from public lists (sources.py), schedules from sports.py, films from
archive.py. Favorites and recently watched are kept on this device.
"""

import json
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from . import archive, catalog, presets, sports
from .kodiutil import (L, PLAYING_PROPERTY, add_recent, addon, catalog as load_catalog, day_and_clock, failed_urls,
                       favorites, log, recent, set_favorite)
from .sources import SourceError

ICON = "special://home/addons/plugin.video.kodaches/resources/icon.png"
FANART = "special://home/addons/plugin.video.kodaches/resources/fanart.jpg"
FILM_PAGE = 40


class Plugin:
    def __init__(self, argv):
        self.base = argv[0]
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip("?")))

    def url(self, **params):
        return self.base + "?" + urlencode(params)

    # --- list helpers -----------------------------------------------------------

    def folder(self, label, mode, icon=ICON, plot="", **params):
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        if plot:
            li.getVideoInfoTag().setPlot(plot)
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode=mode, **params), li, isFolder=True)

    def action(self, label, mode, icon=ICON, **params):
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode=mode, **params), li, isFolder=False)

    def end(self, content="videos", cache=False):
        xbmcplugin.setContent(self.handle, content)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def notify(self, message, error=False):
        xbmcgui.Dialog().notification("Kodaches", message,
                                      xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 4000)

    def channels(self, force=False):
        """The catalog, minus channels whose every feed failed today (unless the viewer wants them)."""
        progress = []

        def show():
            dialog = xbmcgui.DialogProgressBG()
            dialog.create("Kodaches", L(30200))
            progress.append(dialog)
        try:
            all_channels = load_catalog(force=force, progress=show)
        finally:
            for dialog in progress:
                dialog.close()
        if addon().getSettingBool("show_unavailable"):
            return all_channels
        failed = failed_urls()
        return [c for c in all_channels if catalog.available(c, failed)]

    # --- home -------------------------------------------------------------------

    def root(self):
        self.folder(L(30101), "live")
        self.folder(L(30110), "section", key="german")
        self.folder(L(30111), "section", key="us")
        self.folder(L(30112), "section", key="local")
        self.folder(L(30104), "sports")
        self.folder(L(30114), "section", key="news")
        self.folder(L(30115), "section", key="kids")
        self.folder(L(30105), "movies")
        self.folder(L(30122), "music")
        self.folder(L(30118), "section", key="fast")
        self.folder(L(30107), "search")
        self.folder(L(30108), "favorites")
        self.folder(L(30109), "recent")
        self.action(L(30123), "apps")
        self.folder(L(30124), "settings")
        self.end("files")

    def apps(self):
        xbmc.executebuiltin("ActivateWindow(addonbrowser)")

    # --- live TV ----------------------------------------------------------------

    def channel_item(self, c, favs):
        li = xbmcgui.ListItem(c["name"])
        logo = c.get("logo") or ICON
        li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
        tag = li.getVideoInfoTag()
        tag.setTitle(c["name"])
        tag.setGenres([c["group"]])
        notes = [c["group"]] + [f for f in c["flags"] if ":" not in f]  # e.g. "Geo-blocked", "Not 24/7"
        tag.setPlot(" · ".join(notes))
        tag.setMediaType("video")
        li.setProperty("IsPlayable", "true")
        fav = c["id"] in favs
        li.addContextMenuItems([(L(30135) if fav else L(30134),
                                 "RunPlugin(%s)" % self.url(mode="fav", id=c["id"], value=0 if fav else 1))])
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play", id=c["id"]), li, isFolder=False)

    def channel_list(self, channels, sort=True):
        favs = set(favorites())
        if not channels:
            self.notify(L(30205))
        for c in (catalog.sort_channels(channels) if sort else channels):
            self.channel_item(c, favs)
        self.end("videos")

    def live(self):
        channels = self.channels()
        for key, sid, count in catalog.section_counts(channels):
            if count:
                self.folder("%s (%d)" % (L(sid), count), "section", key=key)
        self.folder("%s (%d)" % (L(30125), len(channels)), "all")
        self.action(L(30136), "refresh")
        self.end("files")

    def all(self):
        self.channel_list(self.channels())

    def section(self):
        key = self.params["key"]
        channels = catalog.section(self.channels(), key)
        if key == "local" and not channels:
            xbmcgui.Dialog().ok(L(30112), L(30206))
        subs = catalog.subfolders(channels, key)
        if len(subs) <= 1 or len(channels) <= 30:
            return self.channel_list(channels)
        self.folder("%s (%d)" % (L(30125), len(channels)), "section_all", key=key)
        for value, label, count in subs:
            self.folder("%s (%d)" % (label, count), "subfolder", key=key, value=value)
        self.end("files")

    def section_all(self):
        self.channel_list(catalog.section(self.channels(), self.params["key"]))

    def subfolder(self):
        key = self.params["key"]
        self.channel_list(catalog.in_subfolder(catalog.section(self.channels(), key), key, self.params["value"]))

    def play(self):
        channel = next((c for c in load_catalog() if c["id"] == self.params["id"]), None)
        if not channel:
            self.notify(L(30202), error=True)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        urls = catalog.playable_urls(channel, failed_urls())
        li = xbmcgui.ListItem(channel["name"], path=urls[0])
        li.setArt({"icon": channel.get("logo") or ICON, "thumb": channel.get("logo") or ICON})
        li.setContentLookup(False)
        if channel["kind"] == "hls":
            li.setMimeType("application/vnd.apple.mpegurl")
            if addon().getSettingBool("use_isa") and xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
                li.setProperty("inputstream", "inputstream.adaptive")
        else:
            li.setMimeType("video/mp2t")
        # The service marks feeds that fail and switches to the channel's next feed.
        xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, json.dumps(
            {"id": channel["id"], "name": channel["name"], "urls": urls, "index": 0, "kind": channel["kind"]}))
        add_recent(channel["id"])
        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def fav(self):
        set_favorite(self.params["id"], self.params.get("value") == "1")
        xbmc.executebuiltin("Container.Refresh")

    def favorites(self):
        self.channel_list(catalog.by_ids(self.channels(), favorites()), sort=False)

    def recent(self):
        self.channel_list(catalog.by_ids(self.channels(), recent()), sort=False)

    def refresh(self):
        channels = self.channels(force=True)
        self.notify(L(30207) % len(channels))
        xbmc.executebuiltin("Container.Refresh")

    # --- sports -----------------------------------------------------------------

    def sports(self):
        sports_channels = catalog.section(self.channels(), "sports")
        self.folder("%s (%d)" % (L(30113), len(sports_channels)), "section", key="sports")
        for lg in sports.league_list():
            self.folder(lg["name"], "league", icon=lg["logo"] or ICON, plot=L(30141), id=lg["id"])
        self.end("files")

    def league(self):
        try:
            events = sports.schedule(self.params["id"])
        except SourceError as exc:
            log("schedule: %s" % exc, xbmc.LOGWARNING)
            self.notify(L(30208), error=True)
            return self.end()
        for ev in events:
            if ev["state"] == "in":
                when = "[COLOR red]%s[/COLOR]" % L(30142)
            elif ev["state"] == "post":
                when = L(30144)
            else:
                when = day_and_clock(ev["start"])
            label = "%s  %s" % (when, ev["score"] if ev["score"] and ev["state"] != "pre" else ev["short"])
            if ev["broadcast"]:
                label += "  [COLOR grey]%s[/COLOR]" % ev["broadcast"]
            li = xbmcgui.ListItem(label)
            logo = ev.get("logo") or ICON
            li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
            li.getVideoInfoTag().setPlot("\n".join(filter(None, [
                ev["name"], ev["status_text"], ev["score"], ev["venue"],
                (L(30143) % ev["broadcast"]) if ev["broadcast"] else ""])))
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="event", id=ev["id"]), li, isFolder=False)
        self.end("videos")

    def event(self):
        xbmc.executebuiltin("Action(Info)")  # a schedule entry has nothing to play: show its details

    # --- movies (public-domain films) ---------------------------------------------

    def movies(self):
        self.folder(L(30126), "films", sort="popular")
        self.folder("%s: %s" % (L(30126), L(30129)), "films", sort="newest")
        self.folder("%s: %s" % (L(30126), L(30128)), "films", sort="title")
        self.folder(L(30131), "film_search")
        channels = self.channels()
        names = {key: sid for key, sid, _pred, _split in catalog.SECTIONS}
        for key in ("movies", "series", "documentary"):
            self.folder("%s (%d)" % (L(names[key]), len(catalog.section(channels, key))), "section", key=key)
        self.end("files")

    def films(self):
        start = int(self.params.get("start", 0))
        try:
            data = archive.browse(start, FILM_PAGE, self.params.get("q"), self.params.get("sort", "popular"))
        except SourceError as exc:
            log("archive: %s" % exc, xbmc.LOGWARNING)
            self.notify(L(30209), error=True)
            return self.end()
        for it in data["items"]:
            li = xbmcgui.ListItem(it["title"])
            tag = li.getVideoInfoTag()
            tag.setTitle(it["title"])
            tag.setMediaType("movie")
            tag.setPlot(it["overview"])
            if it["year"]:
                tag.setYear(it["year"])
            if it["genres"]:
                tag.setGenres(it["genres"])
            if it["runtime"]:
                tag.setDuration(it["runtime"])
            li.setArt({"poster": it["poster"], "thumb": it["poster"], "icon": it["poster"], "fanart": FANART})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_film", id=it["id"]), li, isFolder=False)
        if start + FILM_PAGE < data["total"]:
            params = {k: v for k, v in self.params.items() if k != "mode"}
            params["start"] = start + FILM_PAGE
            self.folder(L(30130), "films", **params)
        self.end("movies")

    def film_search(self):
        q = self.params.get("q") or xbmcgui.Dialog().input(L(30131))
        if not q:
            return self.end()
        self.params.update(q=q, sort="popular")
        self.films()

    def play_film(self):
        try:
            url = archive.stream(self.params["id"])
        except SourceError as exc:
            log("film: %s" % exc, xbmc.LOGWARNING)
            self.notify(L(30202), error=True)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
        xbmcplugin.setResolvedUrl(self.handle, True, xbmcgui.ListItem(path=url))

    # --- search, music ------------------------------------------------------------

    def search(self):
        q = self.params.get("q") or xbmcgui.Dialog().input(L(30107))
        if not q:
            return self.end()
        favs = set(favorites())
        for c in catalog.find(self.channels(), q):
            self.channel_item(c, favs)
        self.folder("%s: %s" % (L(30131), q), "film_search", q=q)
        self.end("videos")

    def music(self):
        self.folder(L(30117), "section", key="music")
        self.action(L(30152), "kodi_music")
        self.end("files")

    def kodi_music(self):
        xbmc.executebuiltin("ActivateWindow(Music,root)")

    # --- settings -------------------------------------------------------------------

    def settings(self):
        for key in presets.PRESET_KEYS:
            p = presets.PRESETS[key]
            self.action("%s: %s  [COLOR grey](%s)[/COLOR]" % (L(30145), L(p["label"]), p["inspired"]), "preset", key=key)
        self.action(L(30136), "refresh")
        self.action(L(30155), "updates")
        self.action(L(30146), "language")
        self.action(L(30153), "open_settings")
        self.end("files")

    def updates(self):
        # Kodi's own updater: re-reads every enabled repository, including the Kodaches one.
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")
        self.notify(L(30156))

    def open_settings(self):
        addon().openSettings()

    def preset(self):
        key = self.params["key"]

        def rpc(method, params):
            reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                                "params": params})))
            if "error" in reply:
                raise RuntimeError(reply["error"].get("message", "error"))
            return reply.get("result")

        def wait_for_skin(skin_id):
            monitor = xbmc.Monitor()
            for _ in range(240):  # the viewer confirms the install, then Kodi downloads it
                if xbmc.getCondVisibility("System.HasAddon(%s)" % skin_id):
                    return True
                if monitor.waitForAbort(0.5):
                    return False
            return False

        report = presets.apply(key, rpc, xbmc.executebuiltin, L,
                               lambda sid: bool(xbmc.getCondVisibility("System.HasAddon(%s)" % sid)), wait_for_skin)
        addon().setSetting("preset", key)
        failed = [r for r in report if not r[1]]
        log("preset %s: %s" % (key, report))
        xbmcgui.Dialog().ok("Kodaches", L(30210) % L(presets.PRESETS[key]["label"]) +
                            ("\n" + "\n".join("%s: %s" % (r[0], r[2]) for r in failed) if failed else ""))

    def language(self):
        choice = xbmcgui.Dialog().select(L(30146), ["English", "Deutsch"])
        if choice < 0:
            return
        lang = ["resource.language.en_gb", "resource.language.de_de"][choice]
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % lang):
            xbmc.executebuiltin("InstallAddon(%s)" % lang)
        xbmc.executebuiltin("SetGUILanguage(%s)" % lang)


ROUTES = {
    None: Plugin.root, "live": Plugin.live, "all": Plugin.all, "section": Plugin.section,
    "section_all": Plugin.section_all, "subfolder": Plugin.subfolder, "play": Plugin.play, "fav": Plugin.fav,
    "favorites": Plugin.favorites, "recent": Plugin.recent, "refresh": Plugin.refresh, "sports": Plugin.sports,
    "league": Plugin.league, "event": Plugin.event, "movies": Plugin.movies, "films": Plugin.films,
    "film_search": Plugin.film_search, "play_film": Plugin.play_film, "search": Plugin.search,
    "music": Plugin.music, "kodi_music": Plugin.kodi_music, "apps": Plugin.apps, "settings": Plugin.settings,
    "updates": Plugin.updates, "open_settings": Plugin.open_settings, "preset": Plugin.preset,
    "language": Plugin.language,
}

# Routes that do something instead of listing a folder. Opened as a folder (a favourite, a launcher,
# RunAddon), Kodi waits for a listing that never comes, so they always close the directory.
ACTIONS = {"fav", "refresh", "event", "apps", "kodi_music", "updates", "open_settings", "preset", "language"}


def run(argv=None):
    argv = argv or sys.argv
    plugin = Plugin(argv)
    mode = plugin.params.get("mode")
    if mode not in ROUTES:
        log("unknown mode %s" % mode, xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(plugin.handle, succeeded=False)
    try:
        ROUTES[mode](plugin)
    except SourceError as exc:
        log("source error in %s: %s" % (mode, exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Kodaches", L(30201) % exc, xbmcgui.NOTIFICATION_ERROR, 6000)
        if plugin.handle >= 0 and mode not in ACTIONS:
            if mode in ("play", "play_film"):
                xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())
            else:
                xbmcplugin.endOfDirectory(plugin.handle, succeeded=False)
    finally:
        if mode in ACTIONS and plugin.handle >= 0:
            xbmcplugin.endOfDirectory(plugin.handle, succeeded=False, updateListing=False, cacheToDisc=False)
