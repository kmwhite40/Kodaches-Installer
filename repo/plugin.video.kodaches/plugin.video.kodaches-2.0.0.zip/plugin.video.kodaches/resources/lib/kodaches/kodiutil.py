"""Kodi helpers: settings, strings, and what Kodaches keeps on this device (catalog cache, favorites, history)."""

import json
import os
import time
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcvfs

from . import sources

ADDON_ID = "plugin.video.kodaches"
PLAYING_PROPERTY = "kodaches.playing"
RECENT_LIMIT = 30
FAILED_FOR = 24 * 3600  # a feed that failed is tried last for a day


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def L(string_id):
    return addon().getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Kodaches] %s" % message, level)


def profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo("profile"))
    os.makedirs(path, exist_ok=True)
    return path


def addon_dir():
    return xbmcvfs.translatePath(addon().getAddonInfo("path"))


def _path(name):
    return os.path.join(profile_dir(), name)


def read_json(name, default=None):
    try:
        with open(_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(name, data):
    tmp = _path(name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, _path(name))  # atomic, so the service never reads half a file


# --- channel catalog ----------------------------------------------------------------

_memory = {}


def local_tags():
    try:
        with open(os.path.join(addon_dir(), "resources", "data", "local.json"), encoding="utf-8") as f:
            return json.load(f)["tags"]
    except (OSError, ValueError, KeyError):
        return {}


def catalog(force=False, progress=None):
    """All channels, rebuilt from the public lists every few hours and kept on the device in between."""
    ttl = int(addon().getSetting("refresh_hours") or 6) * 3600
    now = time.time()
    hit = _memory.get("catalog")
    if hit and not force and now - hit[0] < ttl:
        return hit[1]
    disk = None if force else read_json("catalog.json")
    if disk and now - disk.get("at", 0) < ttl and disk.get("version") == 2:
        _memory["catalog"] = (disk["at"], disk["channels"])
        return disk["channels"]
    if progress:
        progress()
    try:
        channels, errors = sources.load(local_tags=local_tags())
    except sources.SourceError:
        if disk:  # offline or iptv-org down: an old list beats none
            _memory["catalog"] = (now, disk["channels"])
            return disk["channels"]
        raise
    for err in errors:
        log("list skipped: %s" % err, xbmc.LOGWARNING)
    write_json("catalog.json", {"version": 2, "at": now, "channels": channels})
    _memory["catalog"] = (now, channels)
    return channels


# --- favorites, recently watched, failed feeds ------------------------------------------

def favorites():
    return read_json("favorites.json", []) or []


def set_favorite(channel_id, value):
    favs = [f for f in favorites() if f != channel_id]
    if value:
        favs.append(channel_id)
    write_json("favorites.json", favs)


def recent():
    return read_json("recent.json", []) or []


def add_recent(channel_id):
    write_json("recent.json", ([channel_id] + [r for r in recent() if r != channel_id])[:RECENT_LIMIT])


def failed_urls():
    now = time.time()
    return {u: t for u, t in (read_json("failed.json", {}) or {}).items() if now - t < FAILED_FOR}


def mark_failed(url):
    failed = failed_urls()
    failed[url] = time.time()
    write_json("failed.json", failed)


def clear_failed(url):
    failed = failed_urls()
    if failed.pop(url, None) is not None:
        write_json("failed.json", failed)


def clock(iso):
    """ISO timestamp -> local "HH:MM" in Kodi's region format."""
    try:
        when = datetime.fromisoformat((iso or "").replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    return when.strftime(xbmc.getRegion("time").replace(":%S", ""))


def day_and_clock(iso):
    try:
        when = datetime.fromisoformat((iso or "").replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    return when.strftime("%a ") + when.strftime(xbmc.getRegion("time").replace(":%S", ""))
