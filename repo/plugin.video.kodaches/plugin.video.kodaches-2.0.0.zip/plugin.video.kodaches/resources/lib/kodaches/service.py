"""
Background service: failover for live channels.

The plugin leaves the channel's feeds (working ones first) in a Home-window property. When a feed
fails to play, the service marks it failed for a day and plays the channel's next feed; once a feed
plays, it is marked good again. Channels with no working feed are hidden from the menus.
"""

import json

import xbmc
import xbmcgui

from .kodiutil import L, PLAYING_PROPERTY, clear_failed, log, mark_failed


class Player(xbmc.Player):
    def _pending(self):
        raw = xbmcgui.Window(10000).getProperty(PLAYING_PROPERTY)
        return json.loads(raw) if raw else None

    def onAVStarted(self):
        info = self._pending()
        if not info:
            return  # films, or something not from Kodaches
        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            return
        current = info["urls"][info["index"]]
        if playing == current or playing.split("|", 1)[0] == current.split("|", 1)[0]:
            clear_failed(current)
            xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)

    def onPlayBackError(self):
        info = self._pending()
        if not info:
            return
        failed = info["urls"][info["index"]]
        mark_failed(failed)
        log("feed failed for %s: %s" % (info["name"], failed.split("|", 1)[0]), xbmc.LOGWARNING)
        info["index"] += 1
        if info["index"] >= len(info["urls"]):
            xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
            xbmcgui.Dialog().notification("Kodaches", L(30202), xbmcgui.NOTIFICATION_WARNING, 5000)
            return
        xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, json.dumps(info))
        xbmcgui.Dialog().notification("Kodaches", L(30211) % info["name"], xbmcgui.NOTIFICATION_INFO, 3000)
        li = xbmcgui.ListItem(info["name"], path=info["urls"][info["index"]])
        li.setContentLookup(False)
        li.setMimeType("application/vnd.apple.mpegurl" if info.get("kind") == "hls" else "video/mp2t")
        self.play(info["urls"][info["index"]], li)


def run():
    monitor = xbmc.Monitor()
    player = Player()  # noqa: F841  (kept alive for its callbacks)
    log("service started")
    monitor.waitForAbort()
    log("service stopped")
