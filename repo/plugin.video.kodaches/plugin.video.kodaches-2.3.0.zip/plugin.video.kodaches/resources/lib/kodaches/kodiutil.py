"""Kodi helpers: settings, strings, and what Kodaches keeps on this device (catalog cache, favorites, history)."""

import json
import os
import tempfile
import time
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcvfs

from . import sources

ADDON_ID = "plugin.video.kodaches"
PLAYING_PROPERTY = "kodaches.playing"
RECENT_LIMIT = 30
FAILED_FOR = 24 * 3600  # a feed that failed is tried last for a day
HEALTH_REQUEST = "kodaches.health.request"
HEALTH_STATUS = "kodaches.health.status"
GUIDE_REQUEST = "kodaches.guide.request"


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def L(string_id):
    return addon().getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Kodaches] %s" % message, level)


def profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo("profile"))
    os.makedirs(path, exist_ok=True)
    return path


def addon_dir():
    return xbmcvfs.translatePath(addon().getAddonInfo("path"))


def _path(name):
    return os.path.join(profile_dir(), name)


def read_json(name, default=None):
    try:
        with open(_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(name, data):
    # A unique temp file per write: home-screen rows load in parallel and would race on one name.
    fd, tmp = tempfile.mkstemp(prefix=name + ".", suffix=".tmp", dir=profile_dir())
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, _path(name))  # atomic, so readers never see half a file
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


# --- channel catalog ----------------------------------------------------------------

_memory = {}


def local_tags():
    try:
        with open(os.path.join(addon_dir(), "resources", "data", "local.json"), encoding="utf-8") as f:
            return json.load(f)["tags"]
    except (OSError, ValueError, KeyError):
        return {}


# Bumped when the way channels are built changes, so a device does not keep an older list for hours.
CATALOG_VERSION = 3
RETRY_INCOMPLETE = 15 * 60


def catalog(force=False, progress=None):
    """All channels, rebuilt from the public lists every few hours and kept on the device in between."""
    ttl = int(addon().getSetting("refresh_hours") or 6) * 3600
    now = time.time()
    hit = _memory.get("catalog")
    if hit and not force and now - hit[0] < ttl:
        return hit[1]
    disk = None if force else read_json("catalog.json")
    if disk and now - disk.get("at", 0) < ttl and disk.get("version") == CATALOG_VERSION:
        _memory["catalog"] = (disk["at"], disk["channels"])
        return disk["channels"]
    if progress:
        progress()
    try:
        channels, errors = sources.load(local_tags=local_tags())
    except sources.SourceError:
        if disk:  # offline or iptv-org down: an old list beats none
            kept = [c for c in disk["channels"] if not sources.KODI_REFUSED_RE.search(c["url"])]
            _memory["catalog"] = (now, kept)
            return kept
        raise
    for err in errors:
        log("list skipped: %s" % err, xbmc.LOGWARNING)
    # A list was missing (Local or Sports could be empty): try again in 15 minutes, not after the full refresh time.
    at = now - ttl + RETRY_INCOMPLETE if errors else now
    write_json("catalog.json", {"version": CATALOG_VERSION, "at": at, "channels": channels})
    _memory["catalog"] = (at, channels)
    return channels


# --- favorites, recently watched, failed feeds ------------------------------------------

def favorites():
    return read_json("favorites.json", []) or []


def set_favorite(channel_id, value):
    favs = [f for f in favorites() if f != channel_id]
    if value:
        favs.append(channel_id)
    write_json("favorites.json", favs)


def recent():
    return read_json("recent.json", []) or []


def add_recent(channel_id):
    write_json("recent.json", ([channel_id] + [r for r in recent() if r != channel_id])[:RECENT_LIMIT])


def failed_urls():
    now = time.time()
    return {u: t for u, t in (read_json("failed.json", {}) or {}).items() if now - t < FAILED_FOR}


def mark_failed(url):
    failed = failed_urls()
    failed[url] = time.time()
    write_json("failed.json", failed)


def clear_failed(url):
    failed = failed_urls()
    if failed.pop(url, None) is not None:
        write_json("failed.json", failed)


# --- background health checks (service.py) ---------------------------------------------

def health():
    """{url: [alive, seconds to first media, checked at]} from the last checks."""
    return read_json("health.json", {}) or {}


def save_health(results):
    write_json("health.json", results)


def health_ttl():
    return int(addon().getSetting("refresh_hours") or 6) * 3600


def unavailable_urls():
    """Feeds not to offer first: failed while playing today, or found dead by the last health check."""
    out = failed_urls()
    now = time.time()
    for url, (alive, _secs, at) in health().items():
        if not alive and now - at < max(health_ttl(), FAILED_FOR):
            out.setdefault(url, at)
    return out


def feed_speeds():
    return {url: secs for url, (alive, secs, _at) in health().items() if alive}


def addon_state(addon_id):
    """(installed, enabled). System.HasAddon is false for installed-but-disabled add-ons, such as the
    IPTV Simple client Kodi ships disabled, so ask JSON-RPC instead."""
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled"]}})))
    details = (reply.get("result") or {}).get("addon")
    return (True, bool(details.get("enabled"))) if details else (False, False)


def enable_addon(addon_id):
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                    "params": {"addonid": addon_id, "enabled": True}}))


_now_next = {}


def now_next():
    """{channel name: (now title, next title)} from Kodi's TV guide (IPTV Simple), cached for a minute."""
    hit = _now_next.get("data")
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    data = {}
    if xbmc.getCondVisibility("System.HasPVRAddon"):
        try:
            reply = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "PVR.GetChannels",
                "params": {"channelgroupid": "alltv", "properties": ["broadcastnow", "broadcastnext"]}})))
            for ch in (reply.get("result") or {}).get("channels") or []:
                now = (ch.get("broadcastnow") or {}).get("title") or ""
                nxt = (ch.get("broadcastnext") or {}).get("title") or ""
                if now or nxt:
                    data[ch.get("label", "")] = (now, nxt)
        except (ValueError, TypeError):
            pass
    if data:  # an empty answer usually means the TV section is still loading: ask again next time
        _now_next["data"] = (time.time(), data)
    return data


def clock(iso):
    """ISO timestamp -> local "HH:MM" in Kodi's region format."""
    try:
        when = datetime.fromisoformat((iso or "").replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    return when.strftime(xbmc.getRegion("time").replace(":%S", ""))


def day_and_clock(iso):
    try:
        when = datetime.fromisoformat((iso or "").replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    return when.strftime("%a ") + when.strftime(xbmc.getRegion("time").replace(":%S", ""))
