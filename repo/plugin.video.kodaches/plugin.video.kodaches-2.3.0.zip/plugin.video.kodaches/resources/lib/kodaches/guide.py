"""
TV guide for Kodi's own TV section. No Kodi imports (unit-tested).

iptv-org channels carry no schedule, so public XMLTV feeds are matched to them the way Galaxy does it:
  1. service id   jmp2.uk/plu-<id> style stream addresses carry the Pluto/Samsung/Plex/Roku channel id,
                  which is the feed's channel id
  2. guide id     iptv-org tvg-id (DasErste.de@SD) vs feed id (Das.Erste.de), punctuation removed
  3. name         channel name vs the feed's display names, same country only
Feeds are streamed from disk twice (channels, then programmes) so a TV stick never holds a whole feed
in memory. The result is one small XMLTV file plus an M3U playlist, read by the IPTV Simple client.
"""

import gzip
import os
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from xml.sax.saxutils import escape, quoteattr

# (url, country). Service feeds first: their id matches are exact. No Pluto TV feeds: Pluto channels are
# not in the catalog (their host refuses Kodi), the Pluto TV add-on has its own guide.
FEEDS = [
    ("https://i.mjh.nz/SamsungTVPlus/us.xml.gz", "us"),
    ("https://i.mjh.nz/Plex/us.xml.gz", "us"),
    ("https://i.mjh.nz/Roku/all.xml.gz", "us"),
    ("https://i.mjh.nz/SamsungTVPlus/de.xml.gz", "de"),
    ("https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz", "de"),
]
SERVICE_ID_RE = re.compile(r"jmp2\.uk/(?:plu|stvp|sam|rok|plex)-([A-Za-z0-9-]+)")
TIME_RE = re.compile(r"^(\d{14})\s*([+-]\d{4})?")


def norm(value):
    return re.sub(r"[^a-z0-9]", "", (value or "").lower())


def name_key(name):
    return norm(re.sub(r"\b(hd|sd|uhd|4k|east|west|us|usa|tv)\b", " ", (name or "").lower()))


def channel_keys(channel):
    """Lookup keys for a catalog channel, strongest first."""
    keys = []
    match = SERVICE_ID_RE.search(channel["url"].partition("|")[0])
    if match:
        keys.append("id:" + match.group(1).lower())
    tvg = channel.get("tvg_id") or ""
    if tvg:
        keys.append("id:" + tvg.lower())
        keys.append("nid:" + norm(tvg.split("@", 1)[0]))
    if channel.get("name"):
        keys.append("name:%s:%s" % (channel.get("country", ""), name_key(channel["name"])))
    return keys


def parse_time(value):
    m = TIME_RE.match(value or "")
    if not m:
        return None
    when = datetime.strptime(m.group(1), "%Y%m%d%H%M%S")
    offset = m.group(2) or "+0000"
    sign = 1 if offset[0] == "+" else -1
    seconds = sign * (int(offset[1:3]) * 3600 + int(offset[3:5]) * 60)
    return when.replace(tzinfo=timezone.utc).timestamp() - seconds


def _open(path):
    with open(path, "rb") as f:
        magic = f.read(2)
    return gzip.open(path, "rb") if magic == b"\x1f\x8b" else open(path, "rb")


def feed_channels(path):
    """{xml channel id: [display names]} without keeping programmes."""
    names = {}
    with _open(path) as f:
        for _event, elem in ET.iterparse(f, events=("end",)):
            if elem.tag == "channel":
                names[elem.get("id", "")] = [d.text.strip() for d in elem.findall("display-name") if d.text]
            if elem.tag in ("channel", "programme"):
                elem.clear()
    return names


def match(channels, feeds):
    """
    channels: catalog channels. feeds: [(feed index, country, {xml id: [names]})] in priority order.
    Returns {channel id: (feed index, xml id)}.
    """
    index = {}
    for fi, country, names in feeds:
        for xml_id, displays in names.items():
            index.setdefault("id:" + xml_id.lower(), (fi, xml_id))
            index.setdefault("nid:" + norm(xml_id), (fi, xml_id))
            for display in displays:
                index.setdefault("name:%s:%s" % (country, name_key(display)), (fi, xml_id))
    out = {}
    for c in channels:
        for key in channel_keys(c):
            if key in index:
                out[c["id"]] = index[key]
                break
    return out


def write_guide(channels, feed_paths, mapping, out_path, hours_before=2, hours_after=48, now=None):
    """Writes XMLTV with only matched channels' programmes, re-keyed to Kodaches channel ids. Returns count."""
    now = now or time.time()
    lo, hi = now - hours_before * 3600, now + hours_after * 3600
    by_feed = {}
    for cid, (fi, xml_id) in mapping.items():
        by_feed.setdefault(fi, {}).setdefault(xml_id, []).append(cid)
    names = {c["id"]: c["name"] for c in channels}
    tmp = out_path + ".tmp"
    count = 0
    with open(tmp, "w", encoding="utf-8") as out:
        out.write('<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="Kodaches">\n')
        for cid in sorted(mapping):
            out.write("  <channel id=%s><display-name>%s</display-name></channel>\n"
                      % (quoteattr(cid), escape(names.get(cid, cid))))
        for fi, path in enumerate(feed_paths):
            wanted = by_feed.get(fi)
            if not wanted or not path:
                continue
            with _open(path) as f:
                for _event, elem in ET.iterparse(f, events=("end",)):
                    if elem.tag == "programme":
                        targets = wanted.get(elem.get("channel", ""))
                        if targets:
                            start, stop = parse_time(elem.get("start")), parse_time(elem.get("stop"))
                            if start and stop and stop > lo and start < hi:
                                body = programme_body(elem)
                                for cid in targets:
                                    out.write("  <programme start=%s stop=%s channel=%s>%s</programme>\n" % (
                                        quoteattr(elem.get("start")), quoteattr(elem.get("stop")), quoteattr(cid), body))
                                    count += 1
                        elem.clear()
                    elif elem.tag == "channel":
                        elem.clear()
        out.write("</tv>\n")
    os.replace(tmp, out_path)
    return count


def programme_body(elem):
    parts = []
    for tag in ("title", "sub-title", "desc"):
        text = elem.findtext(tag)
        if text:
            parts.append("<%s>%s</%s>" % (tag, escape(text.strip()[:600]), tag))
    for cat in elem.findall("category")[:3]:
        if cat.text:
            parts.append("<category>%s</category>" % escape(cat.text.strip()))
    icon = elem.find("icon")
    if icon is not None and icon.get("src"):
        parts.append("<icon src=%s/>" % quoteattr(icon.get("src")))
    return "".join(parts)


def write_m3u(entries, path):
    """entries: [(channel, url, [group names])]. tvg-id is the Kodaches channel id used in the guide."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as out:
        out.write("#EXTM3U\n")
        for c, url, groups in entries:
            out.write('#EXTINF:-1 tvg-id=%s tvg-name=%s tvg-logo=%s group-title=%s,%s\n%s\n' % (
                quoteattr(c["id"]), quoteattr(c["name"]), quoteattr(c.get("logo") or ""),
                quoteattr(";".join(groups)), c["name"].replace(",", " "), url))
    os.replace(tmp, path)


def iptvsimple_settings(m3u_path, epg_path):
    """Instance settings for Kodi 21's IPTV Simple client, reading both files locally."""
    values = [
        ("kodi_addon_instance_name", "Kodaches"),
        ("kodi_addon_instance_enabled", "true"),
        ("m3uPathType", "0"), ("m3uPath", m3u_path),
        ("m3uRefreshMode", "1"), ("m3uRefreshIntervalMins", "60"),
        ("numberByOrder", "true"), ("startNum", "1"),
        ("epgPathType", "0"), ("epgPath", epg_path), ("epgCache", "true"),
        # Off: InputStream Adaptive 21.5 crashed Kodi on some German live streams in testing.
        ("useInputstreamAdaptiveforHls", "false"),
        ("logoFromEpg", "0"),
    ]
    body = "".join('    <setting id="%s">%s</setting>\n' % (k, escape(v)) for k, v in values)
    return '<settings version="2">\n%s</settings>\n' % body
