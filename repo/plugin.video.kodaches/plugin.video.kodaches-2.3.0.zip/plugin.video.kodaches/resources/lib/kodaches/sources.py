"""
Channel catalog straight from public sources. No Kodi imports (unit-tested with plain pytest).

Every list is an iptv-org playlist of publicly available streams. A channel that appears in
several lists is shown once, with the other lists recorded as its "lists" and any extra feeds
kept as alternates for failover. Nothing here bypasses geo-restrictions, logins or DRM:
streams that do not play where the viewer is are simply marked unavailable on the device.
"""

import json
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

IPTV_ORG = "https://iptv-org.github.io/iptv/"
USER_AGENT = "Kodaches-Kodi/2.0"

# (list key, playlist path). Country and region lists come before category lists, so a channel's
# id and name come from the most specific list.
LISTS = [
    ("de", "countries/de.m3u"),
    ("deu", "languages/deu.m3u"),
    ("us", "countries/us.m3u"),
    ("us-tx", "subdivisions/us-tx.m3u"),
    ("sports", "categories/sports.m3u"),
    ("news", "categories/news.m3u"),
    ("kids", "categories/kids.m3u"),
    ("movies", "categories/movies.m3u"),
    ("series", "categories/series.m3u"),
    ("music", "categories/music.m3u"),
    ("documentary", "categories/documentary.m3u"),
]

ATTRIBUTE_RE = re.compile(r'([\w-]+)="([^"]*)"')
NAME_NOISE_RE = re.compile(r"\s*(\(\d{3,4}[pi]\)|\[[^\]]*\])")
COUNTRY_RE = re.compile(r"\.([a-z]{2})(?:@|$)")

# (address pattern, flag). jmp2.uk is the redirector iptv-org lists for several FAST services.
FAST_RULES = [
    (re.compile(r"jmp2\.uk/plu-|pluto\.tv", re.I), "fast:pluto"),
    (re.compile(r"jmp2\.uk/(?:sam|stvp)-|samsung", re.I), "fast:samsung"),
    (re.compile(r"jmp2\.uk/plex-|plex\.(tv|direct)", re.I), "fast:plex"),
    (re.compile(r"jmp2\.uk/rok-|roku", re.I), "fast:roku"),
    (re.compile(r"tubi\.(video|tv)", re.I), "fast:tubi"),
    (re.compile(r"xumo", re.I), "fast:xumo"),
    (re.compile(r"stirr", re.I), "fast:stirr"),
    (re.compile(r"jmp2\.uk/lg-|lgchannels", re.I), "fast:lg"),
]
# Feeds whose host refuses Kodi (HTTP 403 to Kodi's player, seen on every Pluto channel in testing).
# They are left out; the official Pluto TV add-on in Streaming apps is the way to watch them in Kodi.
KODI_REFUSED_RE = re.compile(r"jmp2\.uk/plu-", re.I)


class SourceError(Exception):
    pass


def fetch(url, timeout=25):
    try:
        with urlopen(Request(url, headers={"User-Agent": USER_AGENT}), timeout=timeout) as resp:
            return resp.read().decode("utf-8", "replace")
    except Exception as exc:
        raise SourceError("%s: %s" % (url, getattr(exc, "reason", exc)))


def fetch_json(url, timeout=25):
    try:
        return json.loads(fetch(url, timeout))
    except ValueError as exc:
        raise SourceError("%s: %s" % (url, exc))


def slug(value):
    return re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-") or "channel"


def fast_flag(url):
    for pattern, flag in FAST_RULES:
        if pattern.search(url or ""):
            return flag
    return None


def kodi_url(url, headers):
    """Kodi takes HTTP headers after a '|' in the address: url|User-Agent=...&Referer=..."""
    if not headers:
        return url
    return url + "|" + "&".join("%s=%s" % (k, quote(v, safe="")) for k, v in sorted(headers.items()))


def parse_m3u(text):
    """[{"attrs", "title", "url", "headers"}] from an M3U playlist, including #EXTVLCOPT headers."""
    entries, pending = [], None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTINF"):
            attrs = dict(ATTRIBUTE_RE.findall(line))
            title = line.rsplit(",", 1)[-1].strip() if "," in line else ""
            pending = {"attrs": attrs, "title": attrs.get("tvg-name") or title or "Channel", "headers": {}}
        elif line.startswith("#EXTVLCOPT:") and pending is not None:
            key, _, value = line[len("#EXTVLCOPT:"):].partition("=")
            name = {"http-referrer": "Referer", "http-user-agent": "User-Agent", "http-origin": "Origin"}.get(key.strip())
            if name and value.strip():
                pending["headers"][name] = value.strip()
        elif not line.startswith("#") and pending is not None:
            if line.startswith(("http://", "https://")):
                pending["url"] = line
                entries.append(pending)
            pending = None
    return entries


def build(playlists, local_tags=None):
    """
    playlists: [(list key, M3U text)] in LISTS order. local_tags: {tvg-id lower: [flags]}.
    Returns channels: {"id", "name", "group", "logo", "url", "alternates", "kind", "flags", "lists", "country", "tvg_id"}.
    """
    local_tags = local_tags or {}
    # Same channel: the same stream, the same full tvg-id, or (from an EARLIER list) the same channel
    # before "@". Within one list, "Fox.us@KDFW" and "Fox.us@KRIV" are different stations.
    channels, by_tvg, by_base, by_url = [], {}, {}, {}
    for key, text in playlists:
        bases_here = {}
        for entry in parse_m3u(text):
            if KODI_REFUSED_RE.search(entry["url"]):
                continue
            attrs = entry["attrs"]
            tvg = attrs.get("tvg-id", "")
            base = tvg.lower().split("@", 1)[0] if tvg else ""
            url = kodi_url(entry["url"], entry["headers"])
            existing = (by_url.get(entry["url"]) or (by_tvg.get(tvg.lower()) if tvg else None)
                        or (by_base.get(base) if base else None))
            if existing is not None:
                if key not in existing["lists"]:
                    existing["lists"].append(key)
                if key == "us-tx" and "local:us-tx" not in existing["flags"]:
                    existing["flags"].append("local:us-tx")  # Texas stations are usually in the U.S. list first
                if entry["url"] not in by_url and url not in existing["alternates"]:
                    existing["alternates"].append(url)  # another feed of the same channel: failover
                by_url.setdefault(entry["url"], existing)
                continue
            raw_name = entry["title"]
            name = NAME_NOISE_RE.sub("", raw_name).strip() or raw_name
            group = (attrs.get("group-title") or "General").split(";")[0] or "General"
            country = (COUNTRY_RE.search(tvg.lower()) or [None, ""])[1]
            flags = [f.strip("[]") for f in re.findall(r"\[[^\]]*\]", raw_name)]
            for flag in local_tags.get(tvg.lower(), []) + [fast_flag(entry["url"])]:
                if flag and flag not in flags:
                    flags.append(flag)
            if key == "us-tx" and "local:us-tx" not in flags:
                flags.append("local:us-tx")
            channel = {"id": slug(tvg or name), "name": name, "group": "General" if group == "Undefined" else group,
                       "logo": attrs.get("tvg-logo") or "", "url": url, "alternates": [],
                       "kind": "hls" if ".m3u8" in urlsplit(entry["url"]).path.lower() else "ts",
                       "flags": flags, "lists": [key], "country": country, "tvg_id": tvg}
            channels.append(channel)
            by_url[entry["url"]] = channel
            if tvg:
                by_tvg[tvg.lower()] = channel
            if base:
                bases_here.setdefault(base, channel)
        for base, channel in bases_here.items():
            by_base.setdefault(base, channel)
    # A list can repeat a channel id with a different base (regional feeds): keep ids unique.
    seen = {}
    for c in channels:
        n = seen.get(c["id"], 0)
        seen[c["id"]] = n + 1
        if n:
            c["id"] = "%s-%d" % (c["id"], n + 1)
    return channels


def load(lists=LISTS, local_tags=None, base=IPTV_ORG, workers=6):
    """
    Fetch every playlist in parallel and build the catalog. A list that fails is tried once more (TLS handshakes
    to GitHub Pages time out now and then), then skipped and reported.
    """
    def get(item):
        key, path = item
        try:
            return key, fetch(base + path), None
        except SourceError:
            try:
                return key, fetch(base + path), None
            except SourceError as exc:
                return key, "", str(exc)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(get, lists))
    errors = [err for _k, _t, err in results if err]
    if len(errors) == len(results):
        raise SourceError("no channel list could be loaded: %s" % errors[0])
    return build([(k, t) for k, t, err in results if not err], local_tags), errors
