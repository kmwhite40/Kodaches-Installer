from resources.lib.kodaches.service import run

run()
