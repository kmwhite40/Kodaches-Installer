"""
Kodaches menus and playback. Every folder is one invocation: plugin://plugin.video.kodaches/?mode=...

Data comes from Galaxy (see api.py); this module only turns it into Kodi list items.
"""

import json
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from . import catalog, presets
from .api import GalaxyError
from .discovery import find_server, is_galaxy
from .kodiutil import (L, PLAYING_PROPERTY, addon, cached, clear_cache, clock, forget_session, galaxy, log,
                       save_session, server_url, session, set_server_url)

ICON = "special://home/addons/plugin.video.kodaches/resources/icon.png"
FANART = "special://home/addons/plugin.video.kodaches/resources/fanart.jpg"
PAGE = 60


class Plugin:
    def __init__(self, argv):
        self.base = argv[0]
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip("?")))

    def url(self, **params):
        return self.base + "?" + urlencode(params)

    # --- list helpers -----------------------------------------------------------

    def folder(self, label, mode, icon=ICON, plot="", context=None, **params):
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        if plot:
            li.getVideoInfoTag().setPlot(plot)
        if context:
            li.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode=mode, **params), li, isFolder=True)

    def action(self, label, mode, icon=ICON, **params):
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode=mode, **params), li, isFolder=False)

    def end(self, content="videos", cache=True, sort=False):
        xbmcplugin.setContent(self.handle, content)
        if sort:
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def notify(self, message, error=False):
        xbmcgui.Dialog().notification("Kodaches", message,
                                      xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 4000)

    # --- connection and profiles -----------------------------------------------

    def ensure_server(self):
        if server_url() and is_galaxy(server_url(), timeout=3):
            return True
        return self.find_server(silent_if_found=True)

    def find_server(self, silent_if_found=False):
        progress = xbmcgui.DialogProgress()
        progress.create("Kodaches", L(30207))
        found = find_server(xbmc.getIPAddress() or None)
        progress.close()
        if not found:
            typed = xbmcgui.Dialog().input(L(30211), server_url() or "http://")
            found = typed.strip().rstrip("/") if typed and is_galaxy(typed.strip().rstrip("/"), timeout=4) else None
        if not found:
            xbmcgui.Dialog().ok("Kodaches", L(30200))
            return False
        if found != server_url():
            set_server_url(found)
            forget_session()
        if not silent_if_found:
            self.notify(L(30208) % found)
        return True

    def ensure_profile(self):
        if session().get("token"):
            return True
        return self.pick_profile()

    def pick_profile(self):
        api = galaxy()
        try:
            profiles = api.profiles()
        except GalaxyError as exc:
            xbmcgui.Dialog().ok("Kodaches", L(30204) % exc)
            return False
        if not profiles:
            return False
        labels = [p["username"] + ("  [COLOR grey](kids)[/COLOR]" if p["is_kid"] else "") for p in profiles]
        choice = xbmcgui.Dialog().select(L(30209), labels)
        if choice < 0:
            return False
        p = profiles[choice]
        try:
            if p["has_pin"]:
                pin = xbmcgui.Dialog().numeric(0, L(30201) % p["username"], "", True)
                if not pin:
                    return False
                token = api.profile_session(p["username"], pin)
            elif p["is_kid"]:
                token = api.profile_session(p["username"])
            else:
                password = xbmcgui.Dialog().input(L(30202) % p["username"], option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not password:
                    return False
                token = api.password_session(p["username"], password)
        except GalaxyError as exc:
            xbmcgui.Dialog().ok("Kodaches", str(exc))
            return False
        save_session(token)
        self.notify(L(30203) % token["username"])
        return True

    def ready(self):
        return self.ensure_server() and self.ensure_profile()

    def call(self, fn, *args, **kwargs):
        """Run an API call; on an expired session sign in again once, on other errors tell the viewer."""
        try:
            return fn(*args, **kwargs)
        except GalaxyError as exc:
            if exc.status == 401:
                forget_session()
                if self.pick_profile():
                    return getattr(galaxy(), fn.__name__)(*args, **kwargs)
            self.notify(L(30204) % exc, error=True)
            raise

    def listing(self):
        ttl = int(addon().getSetting("channel_cache") or 120)
        api = galaxy()
        return cached("channels-" + (session().get("username") or ""), ttl, lambda: self.call(api.channels))

    # --- home -------------------------------------------------------------------

    def root(self):
        if not self.ready():
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return
        kid = session().get("is_kid")
        self.folder(L(30103), "continue")
        self.folder(L(30101), "live")
        self.folder(L(30110), "section", key="german")
        self.folder(L(30111), "section", key="us")
        self.folder(L(30112), "section", key="local")
        self.folder(L(30104), "sports")
        self.folder(L(30105), "browse", kind="movies")
        self.folder(L(30106), "browse", kind="shows")
        if not kid:
            self.folder(L(30121), "free")
        self.folder(L(30107), "search")
        self.folder(L(30108), "favorites")
        if not kid:
            self.folder(L(30120), "dvr")
        self.folder(L(30122), "music")
        self.action(L(30123), "apps")
        self.folder(L(30124), "settings")
        self.end("files", cache=False)

    def apps(self):
        xbmc.executebuiltin("ActivateWindow(addonbrowser)")

    # --- live TV ----------------------------------------------------------------

    def channel_item(self, c):
        li = xbmcgui.ListItem(catalog.now_label(c))
        logo = galaxy().absolute(c.get("logo")) or ICON
        li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
        tag = li.getVideoInfoTag()
        tag.setTitle(c["name"])
        tag.setPlot(catalog.plot(c, clock))
        tag.setMediaType("video")
        li.setProperty("IsPlayable", "true")
        fav = c.get("favorite")
        li.addContextMenuItems([
            (L(30133), "Container.Update(%s)" % self.url(mode="guide", id=c["id"])),
            (L(30135) if fav else L(30134), "RunPlugin(%s)" % self.url(mode="fav_channel", id=c["id"], value=0 if fav else 1)),
        ])
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_channel", id=c["id"]), li, isFolder=False)

    def channel_list(self, channels, empty_message=30205):
        if not channels:
            self.notify(L(empty_message))
        for c in catalog.sort_channels(channels):
            self.channel_item(c)
        self.end("videos", cache=False)

    def live(self):
        listing = self.listing()
        channels = listing["channels"]
        if listing.get("favorites"):
            self.folder("%s (%d)" % (L(30108), len(listing["favorites"])), "channels_ids", ids="favorites")
        if listing.get("recent"):
            self.folder("%s (%d)" % (L(30109), len(listing["recent"])), "channels_ids", ids="recent")
        for key, sid, count in catalog.section_counts(channels):
            if count:
                self.folder("%s (%d)" % (L(sid), count), "section", key=key)
        self.folder("%s (%d)" % (L(30125), len(channels)), "sources")
        self.folder(L(30142), "search_guide")
        self.end("files", cache=False)

    def channels_ids(self):
        listing = self.listing()
        self.channel_list(catalog.by_ids(listing["channels"], listing.get(self.params["ids"]) or []))

    def section(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        key = self.params["key"]
        channels = catalog.section(self.listing()["channels"], key)
        if key == "local" and not channels:
            xbmcgui.Dialog().ok(L(30112), L(30206))
        subs = catalog.subfolders(channels, key)
        if len(subs) <= 1 or len(channels) <= 30:
            return self.channel_list(channels)
        self.folder("%s (%d)" % (L(30125), len(channels)), "section_all", key=key)
        for value, label, count in subs:
            self.folder("%s (%d)" % (label, count), "subfolder", key=key, value=value)
        self.end("files", cache=False)

    def section_all(self):
        self.channel_list(catalog.section(self.listing()["channels"], self.params["key"]))

    def subfolder(self):
        key = self.params["key"]
        channels = catalog.section(self.listing()["channels"], key)
        self.channel_list(catalog.in_subfolder(channels, key, self.params["value"]))

    def sources(self):
        listing = self.listing()
        for src in listing.get("sources") or []:
            if src.get("count"):
                self.folder("%s (%d)" % (src["label"], src["count"]), "source", id=src["id"])
        self.end("files", cache=False)

    def source(self):
        self.channel_list([c for c in self.listing()["channels"] if c["source"] == self.params["id"]])

    def guide(self):
        data = self.call(galaxy().channel_guide, self.params["id"])
        ch = data["channel"]
        for p in data["programmes"]:
            li = xbmcgui.ListItem("%s  %s" % (clock(p["start"]), p["title"]))
            tag = li.getVideoInfoTag()
            tag.setTitle(p["title"])
            tag.setPlot("%s - %s\n%s" % (clock(p["start"]), clock(p["stop"]), p.get("description") or ""))
            logo = galaxy().absolute(ch.get("logo")) or ICON
            li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
            li.setProperty("IsPlayable", "true")
            if ch["source"] == "dispatcharr" and not session().get("is_kid"):
                li.addContextMenuItems([(L(30148), "RunPlugin(%s)" % self.url(
                    mode="record", id=ch["id"], start=p["start"], stop=p["stop"], title=p["title"]))])
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_channel", id=ch["id"]), li, isFolder=False)
        self.end("videos", cache=False)

    def fav_channel(self):
        self.call(galaxy().favorite_channel, self.params["id"], self.params.get("value") == "1")
        clear_cache()
        xbmc.executebuiltin("Container.Refresh")

    def play_channel(self):
        try:
            info = self.call(galaxy().play_channel, self.params["id"])
        except GalaxyError:
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        li = xbmcgui.ListItem(info["channel"]["name"], path=info["url"])
        li.setContentLookup(False)
        if info.get("kind") == "hls":
            li.setMimeType("application/vnd.apple.mpegurl")
            if addon().getSettingBool("use_isa") and xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
                li.setProperty("inputstream", "inputstream.adaptive")
        else:
            li.setMimeType("video/mp2t")
        xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def record(self):
        try:
            result = self.call(galaxy().record, self.params["id"], self.params["start"], self.params["stop"],
                               self.params.get("title") or "Recording")
        except GalaxyError:
            return
        self.notify(L(30213) + (" (%s)" % ", ".join(result["conflicts"]) if result.get("conflicts") else ""))

    def search_guide(self):
        q = xbmcgui.Dialog().input(L(30142))
        if not q:
            return self.end()
        self.params["q"] = q
        self.guide_results()

    # --- sports -----------------------------------------------------------------

    def sports(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        self.folder(L(30131), "sports_now")
        channels = catalog.section(self.listing()["channels"], "sports")
        self.folder("%s (%d)" % (L(30113), len(channels)), "section", key="sports")
        try:
            leagues = galaxy().sports_leagues()
        except GalaxyError:
            leagues = []  # Galaxy without the sports schedule API
        for lg in leagues:
            self.folder(lg["name"], "league", id=lg["id"], icon=lg.get("logo") or ICON)
        self.end("files", cache=False)

    def sports_now(self):
        self.channel_list(self.call(galaxy().sports_now))

    def league(self):
        data = self.call(galaxy().sports_events, self.params["id"])
        for ev in data.get("events") or []:
            status = ev.get("status_text") or clock(ev.get("start"))
            label = "%s  %s" % (status, ev["name"])
            airings = ev.get("airings") or []
            if airings:
                label += "  [COLOR lime]%s[/COLOR]" % ", ".join(a["channel_name"] for a in airings[:2])
            li = xbmcgui.ListItem(label)
            li.setArt({"icon": ev.get("logo") or ICON, "thumb": ev.get("logo") or ICON, "fanart": FANART})
            li.getVideoInfoTag().setPlot("\n".join(filter(None, [ev.get("venue"), ev.get("broadcast"), ev.get("score")])))
            if airings:
                li.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_channel", id=airings[0]["channel_id"]),
                                            li, isFolder=False)
            else:
                xbmcplugin.addDirectoryItem(self.handle, "", li, isFolder=False)
        self.end("videos", cache=False)

    # --- library ----------------------------------------------------------------

    def media_item(self, it):
        api = galaxy()
        kind = it.get("type")
        label = it["title"]
        if kind == "episode" and it.get("series_title"):
            label = "%s  S%02dE%02d  %s" % (it["series_title"], it.get("season") or 0, it.get("episode") or 0, it["title"])
        li = xbmcgui.ListItem(label)
        poster = api.absolute(it.get("poster"))
        art = {"poster": poster, "thumb": api.absolute(it.get("thumb")) or poster,
               "fanart": api.absolute(it.get("backdrop")) or FANART, "clearlogo": api.absolute(it.get("logo")),
               "icon": poster or ICON}
        li.setArt({k: v for k, v in art.items() if v})
        tag = li.getVideoInfoTag()
        tag.setTitle(it["title"])
        tag.setPlot(it.get("overview") or "")
        if it.get("year"):
            tag.setYear(int(it["year"]))
        if it.get("genres"):
            tag.setGenres(it["genres"])
        if it.get("rating"):
            tag.setMpaa(it["rating"])
        if it.get("score"):
            tag.setRating(float(it["score"]))
        if it.get("runtime_ms"):
            tag.setDuration(int(it["runtime_ms"] // 1000))
        tag.setPlaycount(1 if it.get("played") else 0)
        if it.get("position_ms") and it.get("runtime_ms"):
            tag.setResumePoint(it["position_ms"] / 1000.0, it["runtime_ms"] / 1000.0)
        fav = it.get("favorite")
        context = [(L(30135) if fav else L(30134), "RunPlugin(%s)" % self.url(mode="fav_item", id=it["id"], value=0 if fav else 1))]
        if kind in ("movie", "episode", "series"):
            played = it.get("played")
            context.append((L(30137) if played else L(30136),
                            "RunPlugin(%s)" % self.url(mode="watched", id=it["id"], value=0 if played else 1)))
        li.addContextMenuItems(context)
        if kind == "series":
            tag.setMediaType("tvshow")
            tag.setTvShowTitle(it["title"])
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="series", id=it["id"]), li, isFolder=True)
        elif kind == "season":
            tag.setMediaType("season")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="season", series=it["series_id"], id=it["id"]),
                                        li, isFolder=True)
        else:
            tag.setMediaType("episode" if kind == "episode" else "movie")
            if kind == "episode":
                tag.setTvShowTitle(it.get("series_title") or "")
                tag.setSeason(int(it.get("season") or 0))
                tag.setEpisode(int(it.get("episode") or 0))
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play", id=it["id"]), li, isFolder=False)

    def items(self, items, content="movies"):
        for it in items:
            self.media_item(it)
        self.end(content, cache=False)

    def continue_watching(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        rows = self.call(galaxy().home)
        shown = set()
        for row in rows:
            for it in row.get("items") or []:
                if it["id"] not in shown and (row.get("title") in ("Continue Watching", "Next Up") or it.get("progress")):
                    shown.add(it["id"])
                    self.media_item(it)
        for row in rows:
            if row.get("title") not in ("Continue Watching", "Next Up") and row.get("items"):
                self.folder(row["title"], "home_row", title=row["title"])
        self.end("movies", cache=False)

    def home_row(self):
        for row in self.call(galaxy().home):
            if row.get("title") == self.params["title"]:
                return self.items(row.get("items") or [])
        self.end()

    def browse(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        kind = self.params["kind"]
        if "sort" not in self.params and "genre" not in self.params:
            self.folder(L(30127), "browse", kind=kind, sort="added")
            self.folder(L(30128), "browse", kind=kind, sort="title")
            self.folder(L(30129), "browse", kind=kind, sort="rating")
            self.folder(L(30126), "genres", kind=kind)
            return self.end("files")
        start = int(self.params.get("start", 0))
        data = self.call(galaxy().browse, kind, start, PAGE, self.params.get("genre"), self.params.get("sort", "added"))
        for it in data.get("items") or []:
            self.media_item(it)
        if start + PAGE < (data.get("total") or 0):
            params = dict(self.params, start=start + PAGE)
            params.pop("mode", None)
            self.folder(L(30130), "browse", **params)
        self.end("tvshows" if kind == "shows" else "movies", cache=False)

    def genres(self):
        kind = self.params["kind"]
        for g in self.call(galaxy().genres, kind):
            name = g["name"] if isinstance(g, dict) else g
            self.folder(name, "browse", kind=kind, genre=name, sort="title")
        self.end("files")

    def series(self):
        data = self.call(galaxy().item, self.params["id"])
        seasons = data.get("seasons") or []
        if len(seasons) == 1:
            return self.items(self.call(galaxy().episodes, self.params["id"], seasons[0]["id"]), "episodes")
        self.items(seasons, "seasons")

    def season(self):
        self.items(self.call(galaxy().episodes, self.params["series"], self.params["id"]), "episodes")

    def fav_item(self):
        self.call(galaxy().set_favorite, self.params["id"], self.params.get("value") == "1")
        xbmc.executebuiltin("Container.Refresh")

    def watched(self):
        self.call(galaxy().set_watched, self.params["id"], self.params.get("value") == "1")
        xbmc.executebuiltin("Container.Refresh")

    def play(self):
        api = galaxy()
        item_id = self.params["id"]
        try:
            item = self.call(api.item, item_id)
        except GalaxyError:
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        try:
            # Kodi's own resume prompt (from the list item's resume point) seeks after the stream opens,
            # so the stream is always requested from the start.
            info = self.call(api.play_item, item_id, 0)
        except GalaxyError:
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        li = xbmcgui.ListItem(item["title"], path=info["url"])
        li.setContentLookup(False)
        if info.get("kind") == "hls":
            li.setMimeType("application/vnd.apple.mpegurl")
        if info.get("subtitles"):
            li.setSubtitles([s["url"] for s in info["subtitles"]])
        tag = li.getVideoInfoTag()
        tag.setTitle(item["title"])
        tag.setPlot(item.get("overview") or "")
        # The service reports progress for this file to Galaxy.
        xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, json.dumps({
            "id": item_id, "url": info["url"], "play_session_id": info.get("play_session_id"),
            "media_source_id": info.get("media_source_id") or item_id}))
        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def free(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        start = int(self.params.get("start", 0))
        data = self.call(galaxy().free_films, start, 40, self.params.get("q"), self.params.get("sort", "popular"))
        for it in data.get("items") or []:
            li = xbmcgui.ListItem(it["title"])
            tag = li.getVideoInfoTag()
            tag.setTitle(it["title"])
            tag.setMediaType("movie")
            tag.setPlot(it.get("overview") or "")
            if it.get("year"):
                tag.setYear(int(it["year"]))
            art = galaxy().absolute(it.get("poster") or it.get("thumb"))
            if art:
                li.setArt({"poster": art, "thumb": art, "fanart": FANART})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_free", id=it["id"]), li, isFolder=False)
        if start + 40 < (data.get("total") or 0):
            self.folder(L(30130), "free", start=start + 40)
        self.end("movies", cache=False)

    def play_free(self):
        try:
            info = self.call(galaxy().play_free, self.params["id"])
        except GalaxyError:
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
        xbmcplugin.setResolvedUrl(self.handle, True, xbmcgui.ListItem(path=info["url"]))

    # --- search, favorites, DVR, music --------------------------------------------

    def search(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        q = self.params.get("q") or xbmcgui.Dialog().input(L(30107))
        if not q:
            return self.end()
        for it in self.call(galaxy().search, q):
            self.media_item(it)
        for c in catalog.find(self.listing()["channels"], q, limit=40):
            self.channel_item(c)
        self.folder("%s: %s" % (L(30142), q), "guide_results", q=q)
        self.end("videos", cache=False)

    def guide_results(self):
        for r in self.call(galaxy().guide_search, self.params["q"]):
            ch, p = r["channel"], r["programme"]
            when = L(30154) if r.get("airing") else clock(p.get("start"))
            li = xbmcgui.ListItem("%s  %s  [COLOR grey]%s[/COLOR]" % (when, p.get("title", ""), ch["name"]))
            li.getVideoInfoTag().setPlot(p.get("description") or "")
            logo = galaxy().absolute(ch.get("logo")) or ICON
            li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_channel", id=ch["id"]), li, isFolder=False)
        self.end("videos", cache=False)

    def favorites(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        listing = self.listing()
        for c in catalog.by_ids(listing["channels"], listing.get("favorites") or []):
            self.channel_item(c)
        for it in self.call(galaxy().my_list):
            self.media_item(it)
        self.end("videos", cache=False)

    def dvr(self):
        try:
            recordings = self.call(galaxy().recordings)
        except GalaxyError:
            return self.end()
        for r in recordings:
            li = xbmcgui.ListItem("%s  [COLOR grey]%s %s[/COLOR]" % (r.get("title"), r.get("status", ""), clock(r.get("start"))))
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_recording", id=r["id"]), li, isFolder=False)
        self.end("videos", cache=False)

    def play_recording(self):
        try:
            info = self.call(galaxy().play_recording, self.params["id"])
        except GalaxyError:
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        xbmcplugin.setResolvedUrl(self.handle, True, xbmcgui.ListItem(path=info["url"]))

    def music(self):
        if not self.ready():
            return xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        self.folder(L(30117), "section", key="music")
        self.action(L(30152), "kodi_music")
        self.end("files")

    def kodi_music(self):
        xbmc.executebuiltin("ActivateWindow(Music,root)")

    # --- settings ---------------------------------------------------------------------

    def settings(self):
        s = session()
        self.action("%s: %s" % (L(30143), s.get("username", "-")), "switch_profile")
        self.action("%s: %s" % (L(30144), server_url() or "-"), "find")
        for key in presets.PRESET_KEYS:
            p = presets.PRESETS[key]
            self.action("%s: %s  [COLOR grey](%s)[/COLOR]" % (L(30145), L(p["label"]), p["inspired"]), "preset", key=key)
        self.action(L(30155), "updates")
        self.action(L(30146), "language")
        self.action(L(30153), "open_settings")
        self.end("files", cache=False)

    def switch_profile(self):
        forget_session()
        if self.pick_profile():
            xbmc.executebuiltin("Container.Refresh")

    def find(self):
        self.find_server()

    def updates(self):
        # Kodi's own updater: re-reads every enabled repository, including the Kodaches one.
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")
        self.notify(L(30156))

    def open_settings(self):
        addon().openSettings()

    def preset(self):
        key = self.params["key"]

        def rpc(method, params):
            reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                                "params": params})))
            if "error" in reply:
                raise RuntimeError(reply["error"].get("message", "error"))
            return reply.get("result")

        def wait_for_skin(skin_id):
            monitor = xbmc.Monitor()
            for _ in range(240):  # the viewer confirms the install, then Kodi downloads it
                if xbmc.getCondVisibility("System.HasAddon(%s)" % skin_id):
                    return True
                if monitor.waitForAbort(0.5):
                    return False
            return False

        report = presets.apply(key, rpc, xbmc.executebuiltin, L,
                               lambda sid: bool(xbmc.getCondVisibility("System.HasAddon(%s)" % sid)), wait_for_skin)
        addon().setSetting("preset", key)
        failed = [r for r in report if not r[1]]
        log("preset %s: %s" % (key, report))
        xbmcgui.Dialog().ok("Kodaches", L(30210) % L(presets.PRESETS[key]["label"]) +
                            ("\n" + "\n".join("%s: %s" % (r[0], r[2]) for r in failed) if failed else ""))

    def language(self):
        choice = xbmcgui.Dialog().select(L(30146), ["English", "Deutsch"])
        if choice < 0:
            return
        lang = ["resource.language.en_gb", "resource.language.de_de"][choice]
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % lang):
            xbmc.executebuiltin("InstallAddon(%s)" % lang)
        xbmc.executebuiltin("SetGUILanguage(%s)" % lang)


ROUTES = {
    None: Plugin.root, "live": Plugin.live, "section": Plugin.section, "section_all": Plugin.section_all,
    "subfolder": Plugin.subfolder, "sources": Plugin.sources, "source": Plugin.source,
    "channels_ids": Plugin.channels_ids, "guide": Plugin.guide, "fav_channel": Plugin.fav_channel,
    "play_channel": Plugin.play_channel, "record": Plugin.record, "search_guide": Plugin.search_guide,
    "sports": Plugin.sports, "sports_now": Plugin.sports_now, "league": Plugin.league,
    "continue": Plugin.continue_watching, "home_row": Plugin.home_row, "browse": Plugin.browse,
    "genres": Plugin.genres, "series": Plugin.series, "season": Plugin.season, "fav_item": Plugin.fav_item,
    "watched": Plugin.watched, "play": Plugin.play, "free": Plugin.free, "play_free": Plugin.play_free,
    "search": Plugin.search, "guide_results": Plugin.guide_results, "favorites": Plugin.favorites,
    "dvr": Plugin.dvr, "play_recording": Plugin.play_recording, "music": Plugin.music,
    "kodi_music": Plugin.kodi_music, "apps": Plugin.apps, "settings": Plugin.settings,
    "switch_profile": Plugin.switch_profile, "find": Plugin.find, "open_settings": Plugin.open_settings, "updates": Plugin.updates,
    "preset": Plugin.preset, "language": Plugin.language,
}


# Routes that do something instead of listing a folder. Opened as a folder (a favourite, a launcher,
# RunAddon), Kodi waits for a listing that never comes, so they always close the directory.
ACTIONS = {"fav_channel", "record", "fav_item", "watched", "apps", "kodi_music", "switch_profile", "find",
           "open_settings", "updates", "preset", "language"}


def run(argv=None):
    argv = argv or sys.argv
    plugin = Plugin(argv)
    route = ROUTES.get(plugin.params.get("mode"))
    if route is None and plugin.params.get("mode"):
        log("unknown mode %s" % plugin.params.get("mode"), xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(plugin.handle, succeeded=False)
    mode = plugin.params.get("mode")
    try:
        route(plugin)
    except GalaxyError as exc:
        log("Galaxy error in %s: %s" % (mode, exc), xbmc.LOGWARNING)
        if plugin.handle >= 0 and mode not in ACTIONS:
            xbmcplugin.endOfDirectory(plugin.handle, succeeded=False)
    finally:
        if mode in ACTIONS and plugin.handle >= 0:
            xbmcplugin.endOfDirectory(plugin.handle, succeeded=False, updateListing=False, cacheToDisc=False)
