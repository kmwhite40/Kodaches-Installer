"""
Find a Galaxy server on the local network, the same way the Galaxy Android app does:
probe every host in this device's /24 on port 8080 for /api/v1/server-info answering
{"product": "galaxy"}. No address is built in.
"""

import json
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.request import Request, urlopen

PORT = 8080


def local_ip():
    """This device's LAN address. Connecting a UDP socket sends no packets."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1", 9))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()


def is_galaxy(base, timeout=0.8):
    try:
        req = Request(base + "/api/v1/server-info", headers={"User-Agent": "Kodaches-Kodi/1.0"})
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8")).get("product") == "galaxy"
    except Exception:
        return False


def candidates(ip):
    parts = ip.split(".")
    if len(parts) != 4 or ip.startswith("127."):
        return []
    prefix = ".".join(parts[:3])
    own = int(parts[3])
    # Nearby addresses first: home servers usually sit low in the range.
    hosts = sorted((h for h in range(1, 255) if h != own), key=lambda h: (h > 32, h))
    return ["http://%s.%d:%d" % (prefix, h, PORT) for h in hosts]


def find_server(ip=None, workers=48, timeout=0.8):
    ip = ip or local_ip()
    bases = candidates(ip)
    if not bases:
        return None
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(is_galaxy, b, timeout): b for b in bases}
        for fut in as_completed(futures):
            if fut.result():
                for other in futures:
                    other.cancel()
                return futures[fut]
    return None
