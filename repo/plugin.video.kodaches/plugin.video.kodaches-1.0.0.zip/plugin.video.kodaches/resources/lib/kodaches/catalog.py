"""
Channel sections for the Kodaches menus, computed from Galaxy's /live/channels listing.

Galaxy already removes duplicate channels across sources, hides dead feeds and
filters kids/adult content per profile. This module only decides which menu a
channel appears under. Pure functions, no Kodi imports.
"""

GERMAN_SOURCES = ("free-de", "free-at", "free-ch", "free-lang-deu")
OWN_SOURCES = ("dispatcharr", "ersatztv")

# Section key -> (string id, predicate). Order is the menu order.
SECTIONS = [
    ("german", 30110, lambda c: c["source"] in GERMAN_SOURCES),
    ("us", 30111, lambda c: c["source"] == "free-us"),
    ("local", 30112, lambda c: any(f.startswith("local:") for f in c.get("flags") or [])),
    ("sports", 30113, lambda c: c.get("group") == "Sports" or c["source"] == "free-sports"),
    ("news", 30114, lambda c: c.get("group") in ("News", "Weather", "Business", "Legislative")),
    ("kids", 30115, lambda c: c.get("group") in ("Kids", "Animation", "Family")),
    ("movies", 30116, lambda c: c.get("group") in ("Movies", "Classic", "Series")),
    ("music", 30117, lambda c: c.get("group") == "Music"),
    ("fast", 30118, lambda c: any(f.startswith("fast:") for f in c.get("flags") or [])),
    ("mine", 30119, lambda c: c["source"] in OWN_SOURCES),
]
SECTION_KEYS = [key for key, _sid, _pred in SECTIONS]

# Labels for flag values Galaxy sets (local:<area>, fast:<provider>).
FLAG_LABELS = {
    "local:dfw": "Dallas - Fort Worth",
    "local:us-tx": "Texas",
    "fast:pluto": "Pluto TV",
    "fast:samsung": "Samsung TV Plus",
    "fast:plex": "Plex",
    "fast:roku": "The Roku Channel",
    "fast:tubi": "Tubi",
    "fast:xumo": "Xumo Play",
    "fast:lg": "LG Channels",
    "fast:stirr": "Stirr",
}


def section(channels, key):
    for skey, _sid, pred in SECTIONS:
        if skey == key:
            return [c for c in channels if pred(c)]
    raise KeyError(key)


def section_counts(channels):
    return [(key, sid, sum(1 for c in channels if pred(c))) for key, sid, pred in SECTIONS]


def subfolders(channels, key):
    """How a section is split one level down: by area/provider flag where the section is flag-based, else by group."""
    if key in ("local", "fast"):
        prefix = key + ":"
        counts = {}
        for c in channels:
            for f in c.get("flags") or []:
                if f.startswith(prefix):
                    counts[f] = counts.get(f, 0) + 1
        return sorted(((f, FLAG_LABELS.get(f, f.split(":", 1)[1]), n) for f, n in counts.items()),
                      key=lambda t: (-t[2], t[1]))
    counts = {}
    for c in channels:
        g = c.get("group") or "General"
        counts[g] = counts.get(g, 0) + 1
    return sorted(((g, g, n) for g, n in counts.items()), key=lambda t: (-t[2], t[1]))


def in_subfolder(channels, key, value):
    if key in ("local", "fast"):
        return [c for c in channels if value in (c.get("flags") or [])]
    return [c for c in channels if (c.get("group") or "General") == value]


def by_ids(channels, ids):
    index = {c["id"]: c for c in channels}
    return [index[i] for i in ids if i in index]


def find(channels, query, limit=60):
    """Channel-name search: names starting with the query first, then names containing it."""
    q = query.strip().lower()
    if not q:
        return []
    starts = [c for c in channels if c["name"].lower().startswith(q)]
    contains = [c for c in channels if q in c["name"].lower() and c not in starts]
    return (starts + contains)[:limit]


def sort_channels(channels):
    return sorted(channels, key=lambda c: (c.get("number") is None, c.get("number") or 0, c["name"].lower()))


def now_label(channel):
    now = channel.get("now") or {}
    return "%s  [COLOR grey]%s[/COLOR]" % (channel["name"], now["title"]) if now.get("title") else channel["name"]


def plot(channel, time_format):
    """Now/next text for the info panel. time_format turns an ISO timestamp into local clock text."""
    lines = []
    for slot in ("now", "next"):
        p = channel.get(slot) or {}
        if p.get("title"):
            when = time_format(p.get("start")) if p.get("start") else ""
            lines.append("[B]%s %s[/B]" % (when, p["title"]))
            if p.get("description"):
                lines.append(p["description"])
    return "\n".join(lines)


def is_sports_programme(programme):
    return any(cat.lower() in ("sports", "sport", "sports event", "football", "soccer", "basketball", "baseball",
                               "hockey", "motorsport", "boxing", "mma", "golf", "tennis")
               for cat in programme.get("categories") or [])
