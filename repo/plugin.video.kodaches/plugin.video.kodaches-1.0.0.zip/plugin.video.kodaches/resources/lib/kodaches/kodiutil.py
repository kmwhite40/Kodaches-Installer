"""Kodi helpers shared by the plugin and the service: settings, strings, saved session, caches."""

import json
import os
import time
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcvfs

from .api import Galaxy

ADDON_ID = "plugin.video.kodaches"
PLAYING_PROPERTY = "kodaches.playing"


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def L(string_id):
    return addon().getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Kodaches] %s" % message, level)


def profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo("profile"))
    os.makedirs(path, exist_ok=True)
    return path


def _path(name):
    return os.path.join(profile_dir(), name)


def read_json(name, default=None):
    try:
        with open(_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(name, data):
    tmp = _path(name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, _path(name))  # atomic, so the service never reads half a file


def server_url():
    return (addon().getSetting("server_url") or "").strip().rstrip("/")


def set_server_url(url):
    addon().setSetting("server_url", url)


def session():
    """{"server", "token", "username", "is_kid", "is_admin"} for the signed-in profile, or {}."""
    s = read_json("session.json", {}) or {}
    return s if s.get("server") == server_url() else {}


def save_session(token_response):
    write_json("session.json", {"server": server_url(), "token": token_response["access_token"],
                                "username": token_response["username"], "is_kid": token_response["is_kid"],
                                "is_admin": token_response["is_admin"], "at": int(time.time())})
    clear_cache()


def forget_session():
    write_json("session.json", {})
    clear_cache()


def galaxy():
    s = session()
    return Galaxy(server_url(), s.get("token"))


# The channel listing is ~2 MB; re-fetching it on every folder makes low-end sticks crawl.
_memory = {}


def cached(name, ttl, loader):
    now = time.time()
    hit = _memory.get(name)
    if hit and now - hit[0] < ttl:
        return hit[1]
    disk = read_json("cache-%s.json" % name)
    if disk and now - disk.get("at", 0) < ttl:
        _memory[name] = (disk["at"], disk["data"])
        return disk["data"]
    data = loader()
    _memory[name] = (now, data)
    write_json("cache-%s.json" % name, {"at": now, "data": data})
    return data


def clear_cache():
    _memory.clear()
    for name in os.listdir(profile_dir()):
        if name.startswith("cache-"):
            try:
                os.remove(_path(name))
            except OSError:
                pass


def clock(iso):
    """ISO timestamp -> local "HH:MM", using Kodi's region time format."""
    try:
        when = datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    fmt = xbmc.getRegion("time").replace(":%S", "")
    return when.strftime(fmt)
