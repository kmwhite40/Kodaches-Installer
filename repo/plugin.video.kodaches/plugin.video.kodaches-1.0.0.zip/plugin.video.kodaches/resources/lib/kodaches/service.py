"""
Background service: reports Kodaches playback to Galaxy, so resume points, Continue Watching
and "watched" follow the profile to the Galaxy Android and Samsung apps.

The plugin leaves a description of what it started in a Home-window property; the
service picks it up when Kodi actually starts playing that file. Resuming is Kodi's own: list items
carry the resume point, Kodi asks "Resume from ...", and seeks after the stream opens.
"""

import json

import xbmc
import xbmcgui

from .api import GalaxyError
from .kodiutil import PLAYING_PROPERTY, galaxy, log

PROGRESS_EVERY = 10  # seconds


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.current = None
        self.position_ms = 0
        self.total_ms = 0

    def _report(self, event, paused=False):
        info = self.current
        if not info:
            return
        try:
            galaxy().report(info["id"], event, info.get("play_session_id"), info["media_source_id"],
                            self.position_ms, paused)
        except GalaxyError as exc:
            log("progress report failed: %s" % exc, xbmc.LOGWARNING)

    def sample(self):
        if self.current and self.isPlayingVideo():
            try:
                self.position_ms = int(self.getTime() * 1000)
                self.total_ms = self.total_ms or int(self.getTotalTime() * 1000)
            except RuntimeError:  # playback ended between the two calls
                pass

    def onAVStarted(self):
        window = xbmcgui.Window(10000)
        raw = window.getProperty(PLAYING_PROPERTY)
        window.clearProperty(PLAYING_PROPERTY)
        self.current = None
        if not raw:
            return  # live TV, archive films, or something not from Kodaches
        info = json.loads(raw)
        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            return
        if playing != info["url"]:
            return
        self.current = info
        self.position_ms, self.total_ms = 0, 0
        self.sample()
        self._report("start")

    def onPlayBackPaused(self):
        self.sample()
        self._report("progress", paused=True)

    def onPlayBackResumed(self):
        self.sample()
        self._report("progress")

    def _finish(self):
        self._report("stop")
        self.current = None

    def onPlayBackStopped(self):
        self._finish()

    def onPlayBackEnded(self):
        # Kodi no longer knows the position here; the end of the file is where playback stopped.
        if self.total_ms:
            self.position_ms = self.total_ms
        self._finish()

    def onPlayBackError(self):
        self._finish()


def run():
    monitor = xbmc.Monitor()
    player = Player()
    log("service started")
    ticks = 0
    while not monitor.waitForAbort(1):
        player.sample()
        ticks += 1
        if player.current and ticks % PROGRESS_EVERY == 0 and not xbmc.getCondVisibility("Player.Paused"):
            player._report("progress")
    log("service stopped")
