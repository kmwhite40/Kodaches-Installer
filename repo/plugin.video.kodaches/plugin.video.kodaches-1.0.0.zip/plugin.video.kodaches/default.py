import sys

from resources.lib.kodaches.plugin import run

run(sys.argv)
