"""
Stream health checks. No Kodi imports.

A feed is alive only if real media comes back: playlists are followed master -> variant -> first
segment, because abandoned channels often keep serving a playlist whose segments are long gone.
Each check also records how long the first media bytes took, so slow feeds sort after fast ones.
The service checks as Kodi (its own User-Agent), so a host that refuses Kodi's player fails the check too.
"""

import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote, urljoin, urlsplit
from urllib.request import Request, urlopen

URI_LINE = re.compile(rb"(?m)^[^#\s][^\r\n]*\r?\n")
CONNECT_TIMEOUT = 5
MAX_HEAD = 65536
DEFAULT_AGENT = "Mozilla/5.0 (Kodaches)"


def split_kodi_url(url):
    """'https://x/a.m3u8|Referer=...&User-Agent=...' -> ('https://x/a.m3u8', {headers})."""
    base, _, tail = url.partition("|")
    headers = {}
    for part in tail.split("&") if tail else []:
        key, _, value = part.partition("=")
        if key:
            headers[key] = unquote(value)
    return base, headers


def first_bytes(url, headers, timeout=CONNECT_TIMEOUT, user_agent=DEFAULT_AGENT):
    """(final url, head bytes) or None. Media stops after one chunk; playlists are read until a URI line."""
    req = Request(url, headers=dict({"User-Agent": user_agent}, **headers))
    try:
        with urlopen(req, timeout=timeout) as resp:
            if resp.status >= 400:
                return None
            head = b""
            while len(head) < MAX_HEAD:
                chunk = resp.read(8192)
                if not chunk:
                    break
                head += chunk
                if not head.lstrip().startswith(b"#EXTM3U") or URI_LINE.search(head):
                    break
            return (resp.geturl(), head) if head else None
    except Exception:
        return None


def probe(url, timeout=CONNECT_TIMEOUT, user_agent=DEFAULT_AGENT):
    """(alive, seconds to first media bytes). A User-Agent in the url (after "|") wins, as in Kodi."""
    started = time.monotonic()
    current, headers = split_kodi_url(url)
    for _ in range(3):
        got = first_bytes(current, headers, timeout, user_agent)
        if not got:
            return False, time.monotonic() - started
        final, head = got
        text = head.lstrip()
        if text[:15].lower().startswith((b"<!doctype", b"<html")):
            return False, time.monotonic() - started
        if not text.startswith(b"#EXTM3U"):
            return bool(text), time.monotonic() - started  # TS / AAC / fMP4 bytes
        lines = [ln.strip() for ln in text.decode("utf-8", "replace").splitlines()]
        uri = next((ln for ln in lines if ln and not ln.startswith("#")), None)
        if not uri:
            return False, time.monotonic() - started
        current = urljoin(final, uri)
    return False, time.monotonic() - started


STREAM_INF_RE = re.compile(r"#EXT-X-STREAM-INF:([^\r\n]*)\r?\n\s*([^#\s][^\r\n]*)")
BANDWIDTH_RE = re.compile(r"(?:^|,)BANDWIDTH=(\d+)")
SEPARATE_AUDIO_RE = re.compile(r"#EXT-X-MEDIA:[^\r\n]*TYPE=AUDIO[^\r\n]*URI=")
MAX_BANDWIDTH = 6000000


def pick_variant(url, max_bandwidth=MAX_BANDWIDTH, timeout=4, user_agent=DEFAULT_AGENT):
    """
    Kodi's own player opens every rendition of an HLS master playlist before it starts (Al Jazeera English: 30 s
    and then "Error creating demuxer"; one rendition: 11 s). Returns one rendition (the best at or under
    max_bandwidth, else the smallest) with the url's Kodi headers kept, or None to play the url as it is:
    not a master, unreadable, or audio in separate renditions (picking one would drop the sound).
    """
    base, headers = split_kodi_url(url)
    try:
        req = Request(base, headers=dict({"User-Agent": user_agent}, **headers))
        with urlopen(req, timeout=timeout) as resp:
            final, text = resp.geturl(), resp.read(MAX_HEAD).decode("utf-8", "replace")
    except Exception:
        return None
    if "#EXT-X-STREAM-INF" not in text or SEPARATE_AUDIO_RE.search(text):
        return None
    variants = []
    for attrs, uri in STREAM_INF_RE.findall(text):
        bandwidth = BANDWIDTH_RE.search(attrs)
        if bandwidth:
            variants.append((int(bandwidth.group(1)), urljoin(final, uri.strip())))
    if not variants:
        return None
    fitting = [v for v in variants if v[0] <= max_bandwidth]
    chosen = max(fitting)[1] if fitting else min(variants)[1]
    tail = url.partition("|")[2]
    return chosen + ("|" + tail if tail else "")


def check_all(urls, workers=8, per_host=2, timeout=CONNECT_TIMEOUT, should_stop=None, on_result=None, before=None,
              user_agent=DEFAULT_AGENT):
    """
    Probe many feeds. Hundreds of channels share a few CDNs (Pluto, Samsung), and hammering one host gets
    the check throttled, so at most per_host probes run against one host at a time.
    before() runs ahead of each probe and may block (the service pauses while video plays).
    Returns {url: (alive, seconds)}; stops early when should_stop() is true.
    """
    gates, lock, results = {}, threading.Lock(), {}

    def one(url):
        if before:
            before()
        if should_stop and should_stop():
            return
        host = urlsplit(url.partition("|")[0]).hostname or ""
        with lock:
            gate = gates.setdefault(host, threading.Semaphore(per_host))
        with gate:
            if should_stop and should_stop():
                return
            result = probe(url, timeout, user_agent)
        with lock:
            results[url] = result
        if on_result:
            on_result(url, result)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(one, urls))
    return results
