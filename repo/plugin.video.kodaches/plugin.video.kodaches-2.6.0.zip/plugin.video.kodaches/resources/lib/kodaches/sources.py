"""
Channel catalog straight from public sources. No Kodi imports (unit-tested with plain pytest).

Every list is an iptv-org playlist of publicly available streams. A channel that appears in
several lists is shown once, with the other lists recorded as its "lists" and any extra feeds
kept as alternates for failover. Nothing here bypasses geo-restrictions, logins or DRM:
streams that do not play where the viewer is are simply marked unavailable on the device.
"""

import json
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

IPTV_ORG = "https://iptv-org.github.io/iptv/"
USER_AGENT = "Kodaches-Kodi/2.0"

# (list key, playlist path). Country and region lists come before category lists, so a channel's
# id and name come from the most specific list.
LISTS = [
    ("de", "countries/de.m3u"),
    ("deu", "languages/deu.m3u"),
    ("us", "countries/us.m3u"),
    ("us-tx", "subdivisions/us-tx.m3u"),
    ("sports", "categories/sports.m3u"),
    ("news", "categories/news.m3u"),
    ("kids", "categories/kids.m3u"),
    ("movies", "categories/movies.m3u"),
    ("series", "categories/series.m3u"),
    ("music", "categories/music.m3u"),
    ("documentary", "categories/documentary.m3u"),
]

ATTRIBUTE_RE = re.compile(r'([\w-]+)="([^"]*)"')
NAME_NOISE_RE = re.compile(r"\s*(\(\d{3,4}[pi]\)|\[[^\]]*\])")
COUNTRY_RE = re.compile(r"\.([a-z]{2})(?:@|$)")

# (address pattern, flag). jmp2.uk is the redirector iptv-org lists for several FAST services.
FAST_RULES = [
    (re.compile(r"jmp2\.uk/plu-|pluto\.tv", re.I), "fast:pluto"),
    (re.compile(r"jmp2\.uk/(?:sam|stvp)-|samsung", re.I), "fast:samsung"),
    (re.compile(r"jmp2\.uk/plex-|plex\.(tv|direct)", re.I), "fast:plex"),
    (re.compile(r"jmp2\.uk/rok-|roku", re.I), "fast:roku"),
    (re.compile(r"tubi\.(video|tv)", re.I), "fast:tubi"),
    (re.compile(r"xumo", re.I), "fast:xumo"),
    (re.compile(r"stirr", re.I), "fast:stirr"),
    (re.compile(r"jmp2\.uk/lg-|lgchannels", re.I), "fast:lg"),
]
# World News: international broadcasters, only from their own servers (iptv-org also lists re-streams of
# most of them on unrelated hosts). (tvg-id, host the feed must come from[, name shown]). Order is the menu order.
# Left out because Kodi 21 does not play their feeds (tested 2026-10-28): DW English, Reuters TV and GB News (Amagi).
WORLD_NEWS = [
    ("AlJazeera.qa@English", "getaj.net"),
    ("BBCNews.uk@Africa", "vs-cmaf-push-ww-live.akamaized.net", "BBC News"),  # bbc_news_channel_hd, worldwide
    ("France24.fr@English", "live.france24.com"),
    ("CNNInternational.us@NorthAmerica", "cloudfront.net"),
    ("NHKWorldJapan.jp@SD", "nhkworld.jp"),
    ("i24NEWSEnglishWorld.il@SD", "immergo.tv"),
    ("AfricanewsEnglish.fr@SD", "cdn-euronews.akamaized.net"),
    ("ABCNews.au@Sydney", "abc-news-dmd-streams-1.akamaized.net"),
    ("CBCNewsNetwork.ca@SD", "cloudfront.net"),
    ("NBCNewsNOW.us@SD", "cloudfront.net"),
    ("LiveNOWfromFOX.us@SD", "amagi.tv"),
    ("ArirangTV.kr@SD", "edgesuite.net"),
    ("CGTN.cn@SD", "amagi.tv"),
    ("France24.fr@French", "live.france24.com"),
    ("France24.fr@Spanish", "live.france24.com"),
    ("AlJazeera.qa@Arabic", "getaj.net"),
    ("France24.fr@Arabic", "live.france24.com"),
    ("BBCArabic.uk@SD", "vs-cmaf-pushb-ww-live.akamaized.net"),
    ("BBCPersian.uk@SD", "vs-cmaf-pushb-ww-live.akamaized.net"),
    ("SkyNewsArabia.ae@HD", "skynewsarabia.com"),
]

# Feeds whose host refuses Kodi (HTTP 403 to Kodi's player, seen on every Pluto channel in testing).
# They are left out; the official Pluto TV add-on in Streaming apps is the way to watch them in Kodi.
KODI_REFUSED_RE = re.compile(r"jmp2\.uk/plu-", re.I)


class SourceError(Exception):
    pass


def fetch(url, timeout=25):
    try:
        with urlopen(Request(url, headers={"User-Agent": USER_AGENT}), timeout=timeout) as resp:
            return resp.read().decode("utf-8", "replace")
    except Exception as exc:
        raise SourceError("%s: %s" % (url, getattr(exc, "reason", exc)))


def fetch_json(url, timeout=25):
    try:
        return json.loads(fetch(url, timeout))
    except ValueError as exc:
        raise SourceError("%s: %s" % (url, exc))


MIME_TYPES = {"hls": "application/vnd.apple.mpegurl", "dash": "application/dash+xml", "ts": "video/mp2t"}


def stream_kind(url):
    path = urlsplit((url or "").partition("|")[0]).path.lower()
    return "dash" if path.endswith(".mpd") else "hls" if ".m3u8" in path else "ts"


QUALITY_FEED_RE = re.compile(r"^(sd|hd|fhd|uhd|4k|\d{3,4}[pi])?$")


def base_key(tvg_id):
    """'DasErste.de@HD' -> 'daserste.de' (qualities of one channel); 'DW.de@English' -> 'dw.de@english'."""
    base, _, feed = (tvg_id or "").lower().partition("@")
    if not base:
        return ""
    return base if QUALITY_FEED_RE.match(feed) else "%s@%s" % (base, feed)


def slug(value):
    return re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-") or "channel"


def fast_flag(url):
    for pattern, flag in FAST_RULES:
        if pattern.search(url or ""):
            return flag
    return None


def kodi_url(url, headers):
    """Kodi takes HTTP headers after a '|' in the address: url|User-Agent=...&Referer=..."""
    if not headers:
        return url
    return url + "|" + "&".join("%s=%s" % (k, quote(v, safe="")) for k, v in sorted(headers.items()))


def parse_m3u(text):
    """[{"attrs", "title", "url", "headers"}] from an M3U playlist, including #EXTVLCOPT headers."""
    entries, pending = [], None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTINF"):
            attrs = dict(ATTRIBUTE_RE.findall(line))
            title = line.rsplit(",", 1)[-1].strip() if "," in line else ""
            pending = {"attrs": attrs, "title": attrs.get("tvg-name") or title or "Channel", "headers": {}}
        elif line.startswith("#EXTVLCOPT:") and pending is not None:
            key, _, value = line[len("#EXTVLCOPT:"):].partition("=")
            name = {"http-referrer": "Referer", "http-user-agent": "User-Agent", "http-origin": "Origin"}.get(key.strip())
            if name and value.strip():
                pending["headers"][name] = value.strip()
        elif not line.startswith("#") and pending is not None:
            if line.startswith(("http://", "https://")):
                pending["url"] = line
                entries.append(pending)
            pending = None
    return entries


def build(playlists, local_tags=None):
    """
    playlists: [(list key, M3U text)] in LISTS order. local_tags: {tvg-id lower: [flags]}.
    Returns channels: {"id", "name", "group", "logo", "url", "alternates", "kind", "flags", "lists", "country", "tvg_id"}.
    """
    local_tags = local_tags or {}
    # Same channel: the same stream, the same full tvg-id, or (from an EARLIER list) the same channel in
    # another quality ("DasErste.de@SD" / "@HD"). A feed named for a language or station ("DW.de@English" /
    # "@Russian", "Fox.us@KDFW" / "@KRIV") is a different channel.
    channels, by_tvg, by_base, by_url = [], {}, {}, {}
    for key, text in playlists:
        bases_here = {}
        for entry in parse_m3u(text):
            if KODI_REFUSED_RE.search(entry["url"]):
                continue
            attrs = entry["attrs"]
            tvg = attrs.get("tvg-id", "")
            base = base_key(tvg)
            url = kodi_url(entry["url"], entry["headers"])
            existing = (by_url.get(entry["url"]) or (by_tvg.get(tvg.lower()) if tvg else None)
                        or (by_base.get(base) if base else None))
            if existing is not None:
                if key not in existing["lists"]:
                    existing["lists"].append(key)
                if key == "us-tx" and "local:us-tx" not in existing["flags"]:
                    existing["flags"].append("local:us-tx")  # Texas stations are usually in the U.S. list first
                if entry["url"] not in by_url and url not in existing["alternates"]:
                    existing["alternates"].append(url)  # another feed of the same channel: failover
                by_url.setdefault(entry["url"], existing)
                continue
            raw_name = entry["title"]
            name = NAME_NOISE_RE.sub("", raw_name).strip() or raw_name
            group = (attrs.get("group-title") or "General").split(";")[0] or "General"
            country = (COUNTRY_RE.search(tvg.lower()) or [None, ""])[1]
            flags = [f.strip("[]") for f in re.findall(r"\[[^\]]*\]", raw_name)]
            for flag in local_tags.get(tvg.lower(), []) + [fast_flag(entry["url"])]:
                if flag and flag not in flags:
                    flags.append(flag)
            if key == "us-tx" and "local:us-tx" not in flags:
                flags.append("local:us-tx")
            channel = {"id": slug(tvg or name), "name": name, "group": "General" if group == "Undefined" else group,
                       "logo": attrs.get("tvg-logo") or "", "url": url, "alternates": [],
                       "kind": stream_kind(entry["url"]),
                       "flags": flags, "lists": [key], "country": country, "tvg_id": tvg}
            channels.append(channel)
            by_url[entry["url"]] = channel
            if tvg:
                by_tvg[tvg.lower()] = channel
            if base:
                bases_here.setdefault(base, channel)
        for base, channel in bases_here.items():
            by_base.setdefault(base, channel)
    tag_world_news(channels)
    # A list can repeat a channel id with a different base (regional feeds): keep ids unique.
    seen = {}
    for c in channels:
        n = seen.get(c["id"], 0)
        seen[c["id"]] = n + 1
        if n:
            c["id"] = "%s-%d" % (c["id"], n + 1)
    return channels


def tag_world_news(channels, world=WORLD_NEWS):
    """Flags World News channels ("world", "world_rank") and plays their own server's feed first."""
    wanted = {entry[0].lower(): (rank, entry[1], entry[2] if len(entry) > 2 else None)
              for rank, entry in enumerate(world)}
    for c in channels:
        rank, host, name = wanted.get((c.get("tvg_id") or "").lower(), (None, None, None))
        if rank is None:
            continue
        feeds = [c["url"]] + c["alternates"]
        own = [u for u in feeds if (urlsplit(u.partition("|")[0]).hostname or "").endswith(host)]
        if not own:
            continue  # only re-streams of this channel are listed: not World News
        c["url"], c["alternates"] = own[0], [u for u in feeds if u != own[0]]
        c["kind"] = stream_kind(own[0])
        if "world" not in c["flags"]:
            c["flags"].append("world")
        c["world_rank"] = rank
        if name:
            c["name"] = name


def load(lists=LISTS, local_tags=None, base=IPTV_ORG, workers=6):
    """
    Fetch every playlist in parallel and build the catalog. A list that fails is tried once more (TLS handshakes
    to GitHub Pages time out now and then), then skipped and reported.
    """
    def get(item):
        key, path = item
        try:
            return key, fetch(base + path), None
        except SourceError:
            try:
                return key, fetch(base + path), None
            except SourceError as exc:
                return key, "", str(exc)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(get, lists))
    errors = [err for _k, _t, err in results if err]
    if len(errors) == len(results):
        raise SourceError("no channel list could be loaded: %s" % errors[0])
    return build([(k, t) for k, t, err in results if not err], local_tags), errors
