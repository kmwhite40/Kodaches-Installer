"""
Background service.

1. Failover: the plugin leaves the channel's feeds (working, fastest first) in a Home-window property.
   When a feed fails to play, the service marks it failed for a day and plays the channel's next feed.
2. Clean-up: every few hours (and on request from the menu) it checks the channel feeds in the
   background, most-watched first, and records which work and how fast. Channels with no working
   feed disappear from the menus; working feeds are tried fastest first. It pauses while video plays,
   so it never competes with what is on screen.
"""

import glob
import json
import os
import re
import threading
import time
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcvfs

from . import catalog, guide, health
from .kodiutil import (GUIDE_REQUEST, HEALTH_REQUEST, HEALTH_STATUS, L, PLAYING_PROPERTY, addon,
                       catalog as load_catalog, clear_failed, favorites, feed_speeds, health as stored_health,
                       health_ttl, log, mark_failed, profile_dir, read_json, recent, save_health, unavailable_urls,
                       write_json, addon_state, stream_item)

CHECK_WORKERS = 6
SAVE_EVERY = 150
GUIDE_EVERY = 12 * 3600
PVR = "pvr.iptvsimple"


class Player(xbmc.Player):
    def _pending(self):
        raw = xbmcgui.Window(10000).getProperty(PLAYING_PROPERTY)
        return json.loads(raw) if raw else None

    def onAVStarted(self):
        info = self._pending()
        if not info:
            return  # films, or something not from Kodaches
        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            return
        current = info["urls"][info["index"]]
        started = {u.split("|", 1)[0] for u in (current, info.get("playing") or current)}
        if playing.split("|", 1)[0] in started:  # the feed, or the rendition picked from it
            clear_failed(current)
            xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)

    def onPlayBackError(self):
        info = self._pending()
        if not info:
            return
        failed = info["urls"][info["index"]]
        mark_failed(failed)
        log("feed failed for %s: %s" % (info["name"], failed.split("|", 1)[0]), xbmc.LOGWARNING)
        info["index"] += 1
        if info["index"] >= len(info["urls"]):
            xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
            xbmcgui.Dialog().notification("Kodaches", L(30202), xbmcgui.NOTIFICATION_WARNING, 5000)
            return
        xbmcgui.Dialog().notification("Kodaches", L(30211) % info["name"], xbmcgui.NOTIFICATION_INFO, 3000)
        li, path = stream_item(info["name"], info["urls"][info["index"]])
        info["playing"] = path
        xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, json.dumps(info))
        self.play(path, li)


class Cleanup:
    def __init__(self, monitor, player):
        self.monitor = monitor
        self.player = player

    def due(self):
        last = (read_json("health-run.json", {}) or {}).get("finished", 0)
        return time.time() - last >= health_ttl()

    def wait_while_playing(self):
        while self.player.isPlayingVideo() and not self.monitor.abortRequested():
            self.monitor.waitForAbort(5)

    def run(self, visible):
        window = xbmcgui.Window(10000)
        channels = load_catalog()
        urls = catalog.check_order(channels, first_ids=favorites() + recent())
        results = stored_health()
        now = time.time()
        # Only feeds not checked recently; a manual clean-up re-checks everything.
        todo = urls if visible else [u for u in urls if now - results.get(u, [0, 0, 0])[2] >= health_ttl()]
        if not todo:
            write_json("health-run.json", {"finished": time.time()})
            return
        progress = None
        if visible:
            progress = xbmcgui.DialogProgressBG()
            progress.create("Kodaches", L(30160))
        done, lock = [0], threading.Lock()

        def on_result(url, result):
            with lock:
                results[url] = [result[0], round(result[1], 2), time.time()]
                done[0] += 1
                if done[0] % SAVE_EVERY == 0:
                    save_health(dict(results))
                if progress:
                    progress.update(int(100 * done[0] / len(todo)), "Kodaches", L(30161) % (done[0], len(todo)))
            window.setProperty(HEALTH_STATUS, "%d/%d" % (done[0], len(todo)))

        log("checking %d feeds" % len(todo))
        started = time.time()
        health.check_all(todo, workers=CHECK_WORKERS, per_host=2, timeout=6,
                         should_stop=self.monitor.abortRequested, on_result=on_result,
                         before=self.wait_while_playing, user_agent=xbmc.getUserAgent())
        save_health(results)
        write_json("health-run.json", {"finished": time.time()})
        window.clearProperty(HEALTH_STATUS)
        dead = sum(1 for c in channels if not catalog.available(
            c, {u: 1 for u, r in results.items() if not r[0]}))
        log("checked %d feeds in %ds; %d channels without a working feed" % (done[0], time.time() - started, dead))
        if progress:
            progress.close()
            xbmcgui.Dialog().notification("Kodaches", L(30162) % (len(channels) - dead, dead),
                                          xbmcgui.NOTIFICATION_INFO, 6000)

    def loop(self):
        if self.monitor.waitForAbort(60):  # let Kodi finish starting up first
            return
        while not self.monitor.abortRequested():
            window = xbmcgui.Window(10000)
            requested = window.getProperty(HEALTH_REQUEST) == "1"
            if requested or self.due():
                window.clearProperty(HEALTH_REQUEST)
                try:
                    self.run(visible=requested)
                except Exception as exc:  # never let the clean-up take the service down
                    log("clean-up failed: %s" % exc, xbmc.LOGWARNING)
            if self.monitor.waitForAbort(10):
                break


def rpc(method, params=None):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                        "params": params or {}})))
    if "error" in reply:
        raise RuntimeError("%s: %s" % (method, reply["error"].get("message")))
    return reply.get("result")


class TVGuide:
    """
    Builds Kodi's TV section from Kodaches: an M3U of channels that have a guide (plus favorites and local
    stations) and an XMLTV guide matched from public feeds, read by the IPTV Simple client.
    """

    def __init__(self, monitor, player):
        self.monitor = monitor
        self.player = player
        self.folder = os.path.join(profile_dir(), "guide")
        os.makedirs(self.folder, exist_ok=True)

    def enabled(self):
        return addon().getSettingBool("tv_guide") and addon_state(PVR)[0]

    def loop(self):
        """Own thread: a long first clean-up must not hold the guide back."""
        if self.monitor.waitForAbort(20):
            return
        while not self.monitor.abortRequested():
            window = xbmcgui.Window(10000)
            requested = window.getProperty(GUIDE_REQUEST) == "1"
            if requested or self.due():
                window.clearProperty(GUIDE_REQUEST)
                try:
                    self.run(visible=requested)
                except Exception as exc:  # never let the guide take the service down
                    log("TV guide failed: %s" % exc, xbmc.LOGWARNING)
            if self.monitor.waitForAbort(5):
                break

    def due(self):
        if not self.enabled():
            return False
        last = (read_json("guide-run.json", {}) or {}).get("finished", 0)
        return time.time() - last >= GUIDE_EVERY

    def download(self):
        paths = []
        for i, (url, _country) in enumerate(guide.FEEDS):
            path = os.path.join(self.folder, "feed%d.xml.gz" % i)
            try:
                with urlopen(Request(url, headers={"User-Agent": "Kodaches-Kodi/2.2"}), timeout=120) as resp, \
                        open(path + ".part", "wb") as f:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)
                os.replace(path + ".part", path)
                paths.append(path)
            except Exception as exc:  # one feed down must not stop the guide
                log("guide feed skipped %s: %s" % (url, exc), xbmc.LOGWARNING)
                paths.append(path if os.path.exists(path) else None)
        return paths

    def run(self, visible):
        if not addon().getSettingBool("tv_guide"):
            return
        progress = None
        if visible:
            progress = xbmcgui.DialogProgressBG()
            progress.create("Kodaches", L(30171))
        try:
            started = time.time()
            failed = unavailable_urls()
            channels = [c for c in load_catalog() if catalog.available(c, failed)]
            paths = self.download()
            feeds = [(i, guide.FEEDS[i][1], guide.feed_channels(p)) for i, p in enumerate(paths) if p]
            mapping = guide.match(channels, feeds)
            favs = set(favorites())
            chosen = [c for c in channels if c["id"] in mapping or c["id"] in favs
                      or any(f.startswith("local:") for f in c["flags"])]
            speeds = feed_speeds()
            sections = [(key, sid, pred) for key, sid, pred, _split in catalog.SECTIONS]
            entries = []
            for c in sorted(chosen, key=lambda c: c["name"].lower()):
                groups = [L(sid) for key, sid, pred in sections if pred(c)]
                if c["id"] in favs:
                    groups.insert(0, L(30108))
                entries.append((c, catalog.playable_urls(c, failed, speeds)[0], groups or [L(30125)]))
            m3u = os.path.join(self.folder, "kodaches.m3u")
            xml = os.path.join(self.folder, "guide.xml")
            guide.write_m3u(entries, m3u)
            programmes = guide.write_guide(channels, paths, mapping, xml)
            self.configure(m3u, xml)
            write_json("guide-run.json", {"finished": time.time(), "channels": len(entries),
                                          "with_guide": len(mapping), "programmes": programmes})
            log("TV guide: %d channels (%d with a guide), %d programmes in %ds"
                % (len(entries), len(mapping), programmes, time.time() - started))
            if visible:
                xbmcgui.Dialog().notification("Kodaches", L(30172) % (len(entries), len(mapping)),
                                              xbmcgui.NOTIFICATION_INFO, 6000)
        finally:
            if progress:
                progress.close()

    def settings_file(self):
        """Our IPTV Simple instance: the one named Kodaches, else the first free slot (never someone else's)."""
        data = xbmcvfs.translatePath("special://profile/addon_data/%s" % PVR)
        os.makedirs(data, exist_ok=True)
        taken = {}
        for path in glob.glob(os.path.join(data, "instance-settings-*.xml")):
            number = int(re.search(r"-(\d+)\.xml$", path).group(1))
            with open(path, encoding="utf-8") as f:
                taken[number] = ">Kodaches<" in f.read()
        for number, ours in sorted(taken.items()):
            if ours:
                return os.path.join(data, "instance-settings-%d.xml" % number)
        number = 1
        while number in taken:
            number += 1
        return os.path.join(data, "instance-settings-%d.xml" % number)

    def configure(self, m3u, xml):
        path = self.settings_file()
        wanted = guide.iptvsimple_settings(m3u, xml)
        current = open(path, encoding="utf-8").read() if os.path.exists(path) else ""
        # IPTV Simple re-reads the playlist hourly by itself; reload it now only when settings change or
        # on the first build, and never while something is playing.
        while self.player.isPlaying() and not self.monitor.abortRequested():
            self.monitor.waitForAbort(10)
        if current != wanted:
            rpc("Addons.SetAddonEnabled", {"addonid": PVR, "enabled": False})
            with open(path, "w", encoding="utf-8") as f:
                f.write(wanted)
        rpc("Addons.SetAddonEnabled", {"addonid": PVR, "enabled": True})


def run():
    monitor = xbmc.Monitor()
    player = Player()
    log("service started")
    threading.Thread(target=Cleanup(monitor, player).loop, name="kodaches-cleanup", daemon=True).start()
    threading.Thread(target=TVGuide(monitor, player).loop, name="kodaches-guide", daemon=True).start()
    monitor.waitForAbort()
    log("service stopped")
