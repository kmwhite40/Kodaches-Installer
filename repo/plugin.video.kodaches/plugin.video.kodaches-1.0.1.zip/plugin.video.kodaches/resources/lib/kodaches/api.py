"""
Galaxy API client. No Kodi imports, so it runs under plain pytest too.

Kodaches does not keep its own channel or library database: Galaxy (the household server)
owns channels, guide data, profiles, favorites and watch history, and every
Kodaches client reads them through this client. That is what keeps Kodi, the
Galaxy Android app and the Samsung app in sync.
"""

import json
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

USER_AGENT = "Kodaches-Kodi/1.0"
# Everything Kodi's own player can decode, so Galaxy chooses direct play over a transcode.
VIDEO_CODECS = ["h264", "hevc", "av1", "vp9", "vp8", "mpeg2video", "mpeg4", "vc1"]
AUDIO_CODECS = ["aac", "ac3", "eac3", "dts", "truehd", "flac", "mp3", "opus", "vorbis", "pcm"]


class GalaxyError(Exception):
    def __init__(self, message, status=0):
        super().__init__(message)
        self.status = status


class Galaxy:
    def __init__(self, base, token=None, timeout=20):
        self.base = (base or "").rstrip("/")
        self.token = token
        self.timeout = timeout

    # --- plumbing -------------------------------------------------------------

    def _request(self, method, path, body=None, params=None, auth=True):
        if not self.base:
            raise GalaxyError("No Galaxy server is set", 0)
        url = self.base + "/api/v1" + path
        if params:
            url += "?" + urlencode({k: v for k, v in params.items() if v is not None})
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if auth and self.token:
            headers["Authorization"] = "Bearer " + self.token
        try:
            with urlopen(Request(url, data=data, headers=headers, method=method), timeout=self.timeout) as resp:
                raw = resp.read()
        except HTTPError as exc:
            detail = ""
            try:
                detail = json.loads(exc.read().decode("utf-8")).get("detail", "")
            except Exception:
                pass
            raise GalaxyError(detail if isinstance(detail, str) and detail else "HTTP %d" % exc.code, exc.code)
        except (URLError, socket.timeout, OSError) as exc:
            raise GalaxyError("Galaxy is not reachable at %s (%s)" % (self.base, getattr(exc, "reason", exc)), 0)
        return json.loads(raw.decode("utf-8")) if raw else None

    def absolute(self, url):
        """Galaxy returns server-relative paths for artwork and internal streams."""
        if not url:
            return ""
        return self.base + url if url.startswith("/") else url

    # --- server and profiles --------------------------------------------------

    def server_info(self):
        return self._request("GET", "/server-info", auth=False)

    def profiles(self):
        return self._request("GET", "/auth/profiles", auth=False)

    def profile_session(self, username, pin=""):
        return self._request("POST", "/auth/profile-session", {"username": username, "pin": pin}, auth=False)

    def password_session(self, username, password):
        return self._request("POST", "/auth/session", {"username": username, "password": password}, auth=False)

    def me(self):
        return self._request("GET", "/auth/me")

    # --- live TV --------------------------------------------------------------

    def channels(self):
        return self._request("GET", "/live/channels")

    def channel_guide(self, channel_id):
        return self._request("GET", "/live/channels/%s/guide" % quote(channel_id, safe=""))

    def guide_search(self, query):
        return self._request("GET", "/live/guide/search", params={"q": query})["results"]

    def sports_now(self):
        return self._request("GET", "/live/sports")["channels"]

    def sports_leagues(self):
        return self._request("GET", "/live/sports/leagues")["leagues"]

    def sports_events(self, league_id):
        return self._request("GET", "/live/sports/leagues/%s" % quote(league_id, safe=""))

    def favorite_channel(self, channel_id, value):
        self._request("POST", "/live/channels/%s/favorite" % quote(channel_id, safe=""), {"value": bool(value)})

    def play_channel(self, channel_id):
        info = self._request("POST", "/live/channels/%s/play" % quote(channel_id, safe=""), params={"client": "native"})
        info["url"] = self.absolute(info["url"])
        return info

    def recordings(self):
        return self._request("GET", "/live/recordings")["recordings"]

    def record(self, channel_id, start, stop, title, description=""):
        return self._request("POST", "/live/recordings", {"channel_id": channel_id, "start": start, "stop": stop,
                                                          "title": title, "description": description})

    def play_recording(self, recording_id):
        info = self._request("POST", "/live/recordings/%s/play" % int(recording_id))
        info["url"] = self.absolute(info["url"])
        return info

    # --- library (Jellyfin through Galaxy) -----------------------------------

    def home(self):
        return self._request("GET", "/library/home")["rows"]

    def browse(self, kind, start=0, limit=60, genre=None, sort="added"):
        return self._request("GET", "/library/%s" % kind,
                             params={"start": start, "limit": limit, "genre": genre, "sort": sort})

    def genres(self, kind):
        return self._request("GET", "/library/%s/genres" % kind)["genres"]

    def item(self, item_id):
        return self._request("GET", "/library/items/%s" % item_id)

    def episodes(self, series_id, season_id):
        return self._request("GET", "/library/shows/%s/seasons/%s" % (series_id, season_id))["episodes"]

    def search(self, query):
        return self._request("GET", "/library/search", params={"q": query})["items"]

    def my_list(self):
        return self._request("GET", "/library/my-list")["items"]

    def play_item(self, item_id, start_ms=None):
        info = self._request("POST", "/library/items/%s/play" % item_id,
                             {"codecs": VIDEO_CODECS, "audio": AUDIO_CODECS, "start_ms": start_ms})
        info["url"] = self.absolute(info["url"])
        for sub in info.get("subtitles", []):
            sub["url"] = self.absolute(sub["url"])
        return info

    def report(self, item_id, event, play_session_id, media_source_id, position_ms, paused=False):
        self._request("POST", "/library/items/%s/progress" % item_id,
                      {"event": event, "play_session_id": play_session_id or "", "media_source_id": media_source_id,
                       "position_ms": max(0, int(position_ms)), "paused": bool(paused)})

    def set_watched(self, item_id, value):
        self._request("POST", "/library/items/%s/watched" % item_id, {"value": bool(value)})

    def set_favorite(self, item_id, value):
        self._request("POST", "/library/items/%s/favorite" % item_id, {"value": bool(value)})

    # --- public-domain films (Internet Archive, through Galaxy) ---------------

    def free_films(self, start=0, limit=40, query=None, sort="popular"):
        return self._request("GET", "/library/free", params={"start": start, "limit": limit, "q": query, "sort": sort})

    def play_free(self, identifier):
        info = self._request("POST", "/library/free/%s/play" % quote(identifier, safe=""))
        info["url"] = self.absolute(info.get("url") or info.get("stream"))
        return info
