"""
Kodaches menus and playback. Every folder is one invocation: plugin://plugin.video.kodaches/?mode=...

Standalone: channels come from public lists (sources.py), schedules from sports.py, films from
archive.py. Favorites and recently watched are kept on this device.
"""

import json
import os
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qsl, quote, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import archive, arctic, catalog, presets, sports
from .kodiutil import (GUIDE_REQUEST, HEALTH_REQUEST, HEALTH_STATUS, L, PLAYING_PROPERTY, add_recent, addon, addon_state,
                       catalog as load_catalog, enable_addon,
                       day_and_clock, feed_speeds, favorites, log, now_next, profile_dir, read_json, recent, set_favorite,
                       install_addon, stream_item, unavailable_urls, use_weather, write_arctic_menu, write_json)
from .sources import SourceError

ICON = "special://home/addons/plugin.video.kodaches/resources/icon.png"
FANART = "special://home/addons/plugin.video.kodaches/resources/fanart.jpg"
FILM_PAGE = 40
CHANNEL_PAGE = 100   # long lists are paged: drawing 1,500 items is what makes TV sticks crawl
WIDGET_SIZE = 30
# Public broadcasters first in the German row.
GERMAN_TOP = ("das erste", "zdf", "3sat", "arte", "phoenix", "ard", "tagesschau", "kika", "dw", "br ", "ndr", "wdr",
              "swr", "mdr", "hr ", "rbb", "zdfneo", "one", "orf", "srf", "welt", "n-tv", "ntv")
WIDGET_LEAGUES = ("nfl", "ncaaf", "nba", "ncaab", "nhl", "mlb", "mls", "epl", "bundesliga", "ucl")
# Official add-ons only: the Kodi repository, or SlyGuy's (listed in the Kodaches repository). Each is signed into
# with the viewer's own account where one is needed. (add-on id, name, description string, group, in the setup's
# preselection). Groups are folders in Streaming apps, in this order.
APP_GROUPS = [("tv", 30185), ("news", 30186), ("sports", 30187), ("german", 30188), ("kids", 30189),
              ("music", 30190), ("tools", 30191)]
SERVICES = [
    ("slyguy.pluto.tv.provider", "Pluto TV", 30179, "tv", True),
    ("slyguy.samsung.tv.plus", "Samsung TV Plus", 30179, "tv", True),
    ("slyguy.plex.live", "Plex Live", 30179, "tv", True),
    ("slyguy.roku", "The Roku Channel", 30179, "tv", False),
    ("plugin.video.youtube", "YouTube", 30165, "tv", True),
    ("plugin.video.crackle", "Crackle", 30192, "tv", False),
    ("script.plex", "Plex", 30193, "tv", False),
    ("slyguy.disney.plus", "Disney+", 30164, "tv", False),
    ("slyguy.paramount.plus", "Paramount+", 30164, "tv", False),
    ("slyguy.hulu", "Hulu", 30164, "tv", False),
    ("slyguy.max", "HBO Max", 30164, "tv", False),
    ("plugin.video.ted.talks", "TED Talks", 30192, "tv", False),
    ("plugin.video.newson", "NewsON (local U.S. news)", 30192, "news", True),
    ("plugin.video.nhklive", "NHK World", 30192, "news", False),
    ("plugin.video.cbcnews", "CBC News", 30192, "news", False),
    ("plugin.video.fox.news", "Fox News", 30192, "news", False),
    ("plugin.video.tagesschau", "Tagesschau", 30192, "news", False),
    ("slyguy.espn", "ESPN", 30164, "sports", False),
    ("slyguy.fox.sports", "FOX Sports", 30164, "sports", False),
    ("plugin.video.ardmediathek_de", "ARD Mediathek", 30192, "german", True),
    ("plugin.video.zdf_de_lite", "ZDF Mediathek", 30192, "german", False),
    ("plugin.video.mediathekview", "MediathekView", 30192, "german", False),
    ("plugin.video.arteplussept", "Arte", 30192, "german", False),
    ("slyguy.pbs.live", "PBS", 30166, "kids", True),
    ("plugin.video.zdftivi", "ZDFtivi", 30192, "kids", False),
    ("plugin.audio.radio_de", "Radio", 30180, "music", True),
    ("plugin.audio.somafm", "SomaFM", 30192, "music", False),
    ("plugin.audio.mixcloud", "Mixcloud", 30181, "music", False),
    ("plugin.audio.soundcloud", "SoundCloud", 30192, "music", False),
    ("plugin.audio.bbcsounds", "BBC Sounds", 30192, "music", False),
    ("script.cu.lrclyrics", "CU LRC Lyrics", 30183, "music", False),
    ("service.subtitles.opensubtitles-com", "OpenSubtitles.com", 30167, "tools", True),
    ("weather.multi", "Multi Weather", 30182, "tools", True),
    ("script.trakt", "Trakt", 30194, "tools", False),
    ("service.upnext", "Up Next", 30195, "tools", False),
    ("script.xbmcbackup", "Backup", 30196, "tools", False),
    ("plugin.program.autocompletion", "AutoCompletion", 30197, "tools", False),
    ("service.libraryautoupdate", "Library Auto Update", 30198, "tools", False),
    ("screensaver.atv4", "Aerial screensaver", 30199, "tools", False),
    ("script.kodi.loguploader", "Kodi Logfile Uploader", 30212, "tools", False),
]
WEATHER = "weather.multi"
APPS_PACK = "script.kodaches.apps"  # Pluto TV, Samsung TV Plus, Plex Live, PBS, YouTube, NewsON, ARD, Radio, ...
KARAOKE = "plugin://plugin.video.youtube/kodion/search/query/?q=karaoke"


class Plugin:
    def __init__(self, argv):
        self.base = argv[0]
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip("?")))

    def url(self, **params):
        return self.base + "?" + urlencode(params)

    # --- list helpers -----------------------------------------------------------

    def folder(self, label, mode, icon=ICON, plot="", **params):
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        if plot:
            li.getVideoInfoTag().setPlot(plot)
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode=mode, **params), li, isFolder=True)

    def action(self, label, mode, icon=ICON, **params):
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode=mode, **params), li, isFolder=False)

    def end(self, content="videos", cache=False):
        xbmcplugin.setContent(self.handle, content)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def notify(self, message, error=False):
        xbmcgui.Dialog().notification("Kodaches", message,
                                      xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 4000)

    def channels(self, force=False):
        """The catalog, minus channels whose every feed failed today (unless the viewer wants them)."""
        progress = []

        def show():
            dialog = xbmcgui.DialogProgressBG()
            dialog.create("Kodaches", L(30200))
            progress.append(dialog)
        try:
            all_channels = load_catalog(force=force, progress=show)
        finally:
            for dialog in progress:
                dialog.close()
        if addon().getSettingBool("show_unavailable"):
            return all_channels
        failed = unavailable_urls()
        return [c for c in all_channels if catalog.available(c, failed)]

    # --- home -------------------------------------------------------------------

    def root(self):
        self.folder(L(30101), "live")
        self.action(L(30170), "tvguide")
        self.folder(L(30110), "section", key="german")
        self.folder(L(30111), "section", key="us")
        self.folder(L(30112), "section", key="local")
        self.folder(L(30104), "sports")
        self.folder(L(30114), "section", key="news")
        self.folder(L(30115), "section", key="kids")
        self.folder(L(30105), "movies")
        self.folder(L(30122), "music")
        self.folder(L(30118), "section", key="fast")
        self.folder(L(30127), "services")
        self.folder(L(30107), "search")
        self.folder(L(30108), "favorites")
        self.folder(L(30109), "recent")
        self.action(L(30123), "apps")
        self.folder(L(30124), "settings")
        self.end("files")

    def apps(self):
        xbmc.executebuiltin("ActivateWindow(addonbrowser)")

    # --- live TV ----------------------------------------------------------------

    def channel_item(self, c, favs, guide=None):
        on = (guide or {}).get(c["name"])
        li = xbmcgui.ListItem("%s  [COLOR grey]%s[/COLOR]" % (c["name"], on[0]) if on and on[0] else c["name"])
        logo = c.get("logo") or ICON
        li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
        tag = li.getVideoInfoTag()
        tag.setTitle(c["name"])
        tag.setGenres([c["group"]])
        notes = [c["group"]] + [f for f in c["flags"] if ":" not in f]  # e.g. "Geo-blocked", "Not 24/7"
        plot = " · ".join(notes)
        if on:
            plot = "[B]%s[/B]%s\n%s" % (on[0], ("\n%s %s" % (L(30176), on[1])) if on[1] else "", plot)
        tag.setPlot(plot)
        tag.setMediaType("video")
        li.setProperty("IsPlayable", "true")
        fav = c["id"] in favs
        li.addContextMenuItems([(L(30135) if fav else L(30134),
                                 "RunPlugin(%s)" % self.url(mode="fav", id=c["id"], value=0 if fav else 1))])
        xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play", id=c["id"]), li, isFolder=False)

    def channel_list(self, channels, sort=True):
        favs = set(favorites())
        guide = now_next()
        if not channels:
            self.notify(L(30205))
        ordered = catalog.sort_channels(channels) if sort else channels
        start = int(self.params.get("start", 0))
        for c in ordered[start:start + CHANNEL_PAGE]:
            self.channel_item(c, favs, guide)
        if start + CHANNEL_PAGE < len(ordered):
            params = {k: v for k, v in self.params.items() if k not in ("mode", "start")}
            self.folder("%s (%d-%d / %d)" % (L(30130), start + CHANNEL_PAGE + 1,
                                              min(start + 2 * CHANNEL_PAGE, len(ordered)), len(ordered)),
                        self.params.get("mode", "all"), start=start + CHANNEL_PAGE, **params)
        self.end("videos")

    def live(self):
        channels = self.channels()
        for key, sid, count in catalog.section_counts(channels):
            if count:
                self.folder("%s (%d)" % (L(sid), count), "section", key=key)
        self.folder("%s (%d)" % (L(30125), len(channels)), "all")
        self.action(self.cleanup_label(), "cleanup")
        self.action(L(30136), "refresh")
        self.end("files")

    def cleanup_label(self):
        running = xbmcgui.Window(10000).getProperty(HEALTH_STATUS)
        if running:
            return "%s  [COLOR grey](%s)[/COLOR]" % (L(30147), L(30161) % tuple(int(x) for x in running.split("/")))
        last = (read_json("health-run.json", {}) or {}).get("finished")
        if not last:
            return L(30147)
        hours = max(0, int((time.time() - last) // 3600))
        return "%s  [COLOR grey](%s)[/COLOR]" % (L(30147), L(30148) % hours)

    def cleanup(self):
        xbmcgui.Window(10000).setProperty(HEALTH_REQUEST, "1")  # the service picks it up within seconds
        self.notify(L(30157))

    def all(self):
        self.channel_list(self.channels())

    def section(self):
        key = self.params["key"]
        channels = catalog.section(self.channels(), key)
        if key == "local" and not channels:
            xbmcgui.Dialog().ok(L(30112), L(30206))
        subs = catalog.subfolders(channels, key)
        if len(subs) <= 1 or len(channels) <= 30:
            return self.channel_list(channels, sort=key != "world")
        self.folder("%s (%d)" % (L(30125), len(channels)), "section_all", key=key)
        for value, label, count in subs:
            self.folder("%s (%d)" % (label, count), "subfolder", key=key, value=value)
        self.end("files")

    def section_all(self):
        self.channel_list(catalog.section(self.channels(), self.params["key"]))

    def subfolder(self):
        key = self.params["key"]
        self.channel_list(catalog.in_subfolder(catalog.section(self.channels(), key), key, self.params["value"]))

    def play(self):
        channel = next((c for c in load_catalog() if c["id"] == self.params["id"]), None)
        if not channel:
            self.notify(L(30202), error=True)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        urls = catalog.playable_urls(channel, unavailable_urls(), feed_speeds())
        li, path = stream_item(channel["name"], urls[0])
        li.setArt({"icon": channel.get("logo") or ICON, "thumb": channel.get("logo") or ICON})
        # The service marks feeds that fail and switches to the channel's next feed.
        xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, json.dumps(
            {"id": channel["id"], "name": channel["name"], "urls": urls, "index": 0, "playing": path}))
        add_recent(channel["id"])
        xbmcplugin.setResolvedUrl(self.handle, True, li)

    def fav(self):
        set_favorite(self.params["id"], self.params.get("value") == "1")
        xbmc.executebuiltin("Container.Refresh")

    def favorites(self):
        self.channel_list(catalog.by_ids(self.channels(), favorites()), sort=False)

    def recent(self):
        self.channel_list(catalog.by_ids(self.channels(), recent()), sort=False)

    def refresh(self):
        channels = self.channels(force=True)
        self.notify(L(30207) % len(channels))
        xbmc.executebuiltin("Container.Refresh")

    # --- sports -----------------------------------------------------------------

    def sports(self):
        sports_channels = catalog.section(self.channels(), "sports")
        self.folder("%s (%d)" % (L(30113), len(sports_channels)), "section", key="sports")
        for lg in sports.league_list():
            self.folder(lg["name"], "league", icon=lg["logo"] or ICON, plot=L(30141), id=lg["id"])
        self.end("files")

    def league(self):
        try:
            events = sports.schedule(self.params["id"])
        except SourceError as exc:
            log("schedule: %s" % exc, xbmc.LOGWARNING)
            self.notify(L(30208), error=True)
            return self.end()
        for ev in events:
            if ev["state"] == "in":
                when = "[COLOR red]%s[/COLOR]" % L(30142)
            elif ev["state"] == "post":
                when = L(30144)
            else:
                when = day_and_clock(ev["start"])
            label = "%s  %s" % (when, ev["score"] if ev["score"] and ev["state"] != "pre" else ev["short"])
            if ev["broadcast"]:
                label += "  [COLOR grey]%s[/COLOR]" % ev["broadcast"]
            li = xbmcgui.ListItem(label)
            logo = ev.get("logo") or ICON
            li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
            li.getVideoInfoTag().setPlot("\n".join(filter(None, [
                ev["name"], ev["status_text"], ev["score"], ev["venue"],
                (L(30143) % ev["broadcast"]) if ev["broadcast"] else ""])))
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="event", id=ev["id"]), li, isFolder=False)
        self.end("videos")

    def event(self):
        xbmc.executebuiltin("Action(Info)")  # a schedule entry has nothing to play: show its details

    # --- movies (public-domain films) ---------------------------------------------

    def movies(self):
        self.folder(L(30126), "films", sort="popular")
        self.folder("%s: %s" % (L(30126), L(30129)), "films", sort="newest")
        self.folder("%s: %s" % (L(30126), L(30128)), "films", sort="title")
        self.folder(L(30131), "film_search")
        channels = self.channels()
        names = {key: sid for key, sid, _pred, _split in catalog.SECTIONS}
        for key in ("movies", "series", "documentary"):
            self.folder("%s (%d)" % (L(names[key]), len(catalog.section(channels, key))), "section", key=key)
        self.end("files")

    def films(self):
        start = int(self.params.get("start", 0))
        try:
            data = archive.browse(start, FILM_PAGE, self.params.get("q"), self.params.get("sort", "popular"))
        except SourceError as exc:
            log("archive: %s" % exc, xbmc.LOGWARNING)
            self.notify(L(30209), error=True)
            return self.end()
        self.film_items(data["items"], end=False)
        if start + FILM_PAGE < data["total"]:
            params = {k: v for k, v in self.params.items() if k != "mode"}
            params["start"] = start + FILM_PAGE
            self.folder(L(30130), "films", **params)
        self.end("movies")

    def film_items(self, items, end=True):
        for it in items:
            li = xbmcgui.ListItem(it["title"])
            tag = li.getVideoInfoTag()
            tag.setTitle(it["title"])
            tag.setMediaType("movie")
            tag.setPlot(it["overview"])
            if it["year"]:
                tag.setYear(it["year"])
            if it["genres"]:
                tag.setGenres(it["genres"])
            if it["runtime"]:
                tag.setDuration(it["runtime"])
            li.setArt({"poster": it["poster"], "thumb": it["poster"], "icon": it["poster"], "fanart": FANART})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="play_film", id=it["id"]), li, isFolder=False)
        if end:
            self.end("movies")

    def film_search(self):
        q = self.params.get("q") or xbmcgui.Dialog().input(L(30131))
        if not q:
            return self.end()
        self.params.update(q=q, sort="popular")
        self.films()

    def play_film(self):
        try:
            url = archive.stream(self.params["id"])
        except SourceError as exc:
            log("film: %s" % exc, xbmc.LOGWARNING)
            self.notify(L(30202), error=True)
            return xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
        xbmcplugin.setResolvedUrl(self.handle, True, xbmcgui.ListItem(path=url))

    # --- streaming apps (official add-ons) --------------------------------------------

    def services(self):
        """Streaming apps: a folder per group; inside a group (or as the home row), the apps themselves."""
        group = self.params.get("group")
        if not group and self.params.get("mode") != "widget":
            for key, sid in APP_GROUPS:
                self.folder("%s (%d)" % (L(sid), sum(1 for s in SERVICES if s[3] == key)), "services", group=key)
            return self.end("files")
        for addon_id, name, desc, app_group, featured in SERVICES:
            if group and app_group != group or not group and not featured:
                continue
            installed = xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)
            icon = "special://home/addons/%s/icon.png" % addon_id if installed else ICON
            li = xbmcgui.ListItem(name if installed else "%s  [COLOR grey](%s)[/COLOR]" % (name, L(30137)))
            li.setArt({"icon": icon, "thumb": icon, "fanart": FANART})
            li.getVideoInfoTag().setPlot(L(desc))
            if installed and addon_id.startswith("plugin.audio."):  # opens in Kodi's Music window
                xbmcplugin.addDirectoryItem(self.handle, self.url(mode="open_music", id=addon_id), li, isFolder=False)
            elif installed and addon_id == WEATHER:
                xbmcplugin.addDirectoryItem(self.handle, self.url(mode="open_weather"), li, isFolder=False)
            elif installed and addon_id.startswith(("plugin.video.", "slyguy.")):
                xbmcplugin.addDirectoryItem(self.handle, "plugin://%s/" % addon_id, li, isFolder=True)
            elif installed and addon_id.startswith(("script.", "plugin.program.")):
                xbmcplugin.addDirectoryItem(self.handle, self.url(mode="run_addon", id=addon_id), li, isFolder=False)
            elif installed:  # a service or screensaver: nothing to open but its settings
                xbmcplugin.addDirectoryItem(self.handle, self.url(mode="addon_settings", id=addon_id), li, isFolder=False)
            else:
                xbmcplugin.addDirectoryItem(self.handle, self.url(mode="install", id=addon_id), li, isFolder=False)
        if group not in (None, "music"):
            return self.end("files")
        li = xbmcgui.ListItem(L(30132))
        li.setArt({"icon": ICON, "thumb": ICON, "fanart": FANART})
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcplugin.addDirectoryItem(self.handle, KARAOKE, li, isFolder=True)
        else:
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="install", id="plugin.video.youtube"), li, isFolder=False)
        self.end("files")

    def addon_settings(self):
        xbmc.executebuiltin("Addon.OpenSettings(%s)" % self.params["id"])

    def install_retrying(self, addon_id, attempts=3):
        """
        One failed download (a slow Kodi mirror) fails an add-on and everything it needs (a skin, the apps pack);
        on a new attempt Kodi skips what it already has. Kodi asks again each time.
        """
        for attempt in range(attempts):
            if addon_state(addon_id)[0]:
                return True
            if attempt:
                self.notify(L(30215))
            install_addon(addon_id)
        return addon_state(addon_id)[0]

    def run_addon(self):
        xbmc.executebuiltin("RunAddon(%s)" % self.params["id"])

    def open_music(self):
        xbmc.executebuiltin("ActivateWindow(Music,plugin://%s/,return)" % self.params["id"])

    def open_weather(self):
        use_weather()
        xbmc.executebuiltin("ActivateWindow(Weather)")

    def install(self):
        # From the Kodi repository (YouTube, OpenSubtitles, radio, weather) or SlyGuy's, which the Kodaches
        # repository lists; Kodi asks the viewer to confirm.
        if not install_addon(self.params["id"]) and not addon_state(self.params["id"])[0]:
            self.notify(L(30213))  # Kodi has not loaded the add-on list yet, or the viewer said No
        if self.params["id"] == WEATHER:
            use_weather()
        xbmc.executebuiltin("Container.Refresh")

    # --- home-screen rows (read by the Kodaches skin) ----------------------------------------

    def fastest(self, channels, n=WIDGET_SIZE):
        speeds = feed_speeds()
        return sorted(channels, key=lambda c: speeds.get(c["url"], 50))[:n]

    def widget(self):
        w = self.params.get("w")
        if w == "films":
            try:
                items = archive.browse(0, 20)["items"]
            except SourceError:
                items = []
            return self.film_items(items)
        if w == "games_today":
            return self.games_today()
        if w == "services":
            return self.services()
        if w == "kids_apps":
            self.params["group"] = "kids"
            return self.services()
        channels = self.channels()
        favs = set(favorites())
        guide = now_next()
        if w == "favorites":
            chosen = catalog.by_ids(channels, favorites())[:WIDGET_SIZE]
        elif w == "recent":
            chosen = catalog.by_ids(channels, recent())[:WIDGET_SIZE]
        elif w == "german_top":
            german = catalog.section(channels, "german")
            rank = lambda c: next((i for i, n in enumerate(GERMAN_TOP) if c["name"].lower().startswith(n)), 99)  # noqa: E731
            chosen = sorted(german, key=lambda c: (rank(c), c["name"].lower()))[:WIDGET_SIZE]
        elif w == "us_news":
            chosen = self.fastest([c for c in catalog.section(channels, "us") if c["group"] in ("News", "Weather")])
        elif w == "world_news":
            chosen = catalog.section(channels, "world")[:WIDGET_SIZE]
        elif w == "kids":  # U.S. and German kids' channels first, fastest first
            pool = catalog.section(channels, "kids")
            chosen = self.fastest([c for c in pool if c["country"] in ("us", "de")] or pool)
        elif w in ("local", "fast", "sports_channels"):
            key = "sports" if w == "sports_channels" else w
            pool = catalog.section(channels, key)
            if key == "sports":  # U.S. and German sports channels first
                pool = [c for c in pool if c["country"] in ("us", "de")] + [c for c in pool if c["country"] not in ("us", "de")]
            chosen = pool[:WIDGET_SIZE] if key == "sports" else self.fastest(pool)
        else:
            chosen = []
        for c in chosen:
            self.channel_item(c, favs, guide)
        self.end("videos")

    def games_today(self):
        def today(league_id):
            try:
                return [(league_id, ev) for ev in sports.schedule(league_id, days_back=0, days_ahead=0)]
            except SourceError:
                return []
        cached = read_json("games-today.json", {}) or {}
        if time.time() - cached.get("at", 0) < 300:
            games = cached["games"]
        else:
            with ThreadPoolExecutor(max_workers=5) as pool:
                games = [g for result in pool.map(today, WIDGET_LEAGUES) for g in result]
            order = {"in": 0, "pre": 1, "post": 2}
            games.sort(key=lambda g: (order.get(g[1]["state"], 3), g[1]["start"] or ""))
            write_json("games-today.json", {"at": time.time(), "games": games})
        names = {lg["id"]: lg["name"] for lg in sports.league_list()}
        for league_id, ev in games[:WIDGET_SIZE]:
            when = L(30142) if ev["state"] == "in" else (L(30144) if ev["state"] == "post" else day_and_clock(ev["start"]))
            text = ev["score"] if ev["score"] and ev["state"] != "pre" else ev["short"]
            li = xbmcgui.ListItem("%s  %s" % (when, text))
            logo = ev.get("logo") or ICON
            li.setArt({"icon": logo, "thumb": logo, "fanart": FANART})
            li.getVideoInfoTag().setPlot("\n".join(filter(None, [names.get(league_id, ""), ev["name"], ev["status_text"],
                                                                  (L(30143) % ev["broadcast"]) if ev["broadcast"] else ""])))
            xbmcplugin.addDirectoryItem(self.handle, self.url(mode="league", id=league_id), li, isFolder=True)
        self.end("videos")

    # --- search, music ------------------------------------------------------------

    def search(self):
        q = self.params.get("q") or xbmcgui.Dialog().input(L(30107))
        if not q:
            return self.end()
        favs = set(favorites())
        guide = now_next()
        for c in catalog.find(self.channels(), q):
            self.channel_item(c, favs, guide)
        self.folder("%s: %s" % (L(30131), q), "film_search", q=q)
        self.end("videos")

    def music(self):
        self.folder(L(30117), "section", key="music")
        self.action(L(30152), "kodi_music")
        self.end("files")

    def kodi_music(self):
        xbmc.executebuiltin("ActivateWindow(Music,root)")

    # --- settings -------------------------------------------------------------------

    def settings(self):
        self.action(L(30139), "setup")
        for key in presets.PRESET_KEYS:
            p = presets.PRESETS[key]
            self.action("%s: %s  [COLOR grey](%s)[/COLOR]" % (L(30145), L(p["label"]), p["inspired"]), "preset", key=key)
        self.action(self.cleanup_label(), "cleanup")
        self.action(L(30173), "rebuild_guide")
        self.action(L(30140), "maintenance")
        self.action(L(30136), "refresh")
        self.action(L(30155), "updates")
        self.action(L(30146), "language")
        self.action(L(30153), "open_settings")
        self.end("files")

    def tvguide(self):
        if addon().getSettingBool("tv_guide") and addon_state("pvr.iptvsimple")[1]:
            xbmc.executebuiltin("ActivateWindow(TVGuide)")
        elif xbmcgui.Dialog().yesno("Kodaches", L(30174)):
            self.setup_guide()

    def setup_guide(self):
        """Kodi's TV section, fed by Kodaches through the official IPTV Simple client."""
        installed, _enabled = addon_state("pvr.iptvsimple")
        if not installed:  # Kodi on Android and most Linux packages ship it, disabled
            install_addon("pvr.iptvsimple")
            for _ in range(120):
                if addon_state("pvr.iptvsimple")[0] or xbmc.Monitor().waitForAbort(0.5):
                    break
        if not addon_state("pvr.iptvsimple")[0]:
            self.notify(L(30177), error=True)
            return
        addon().setSettingBool("tv_guide", True)
        xbmcgui.Window(10000).setProperty(GUIDE_REQUEST, "1")  # the service builds it in the background
        self.notify(L(30175))

    def rebuild_guide(self):
        if not addon().getSettingBool("tv_guide"):
            return self.setup_guide()
        xbmcgui.Window(10000).setProperty(GUIDE_REQUEST, "1")
        self.notify(L(30175))

    def setup(self):
        """
        The build: Kodaches look and streaming settings, TV guide, then the free apps in one install (Kodaches Apps
        lists them as dependencies, so Kodi asks once). Run by the Kodaches Build installer with auto=1; from the
        menu it also offers the other apps.
        """
        looks = ["modern", "kodaches"]
        choice = xbmcgui.Dialog().select(L(30216), [L(presets.PRESETS[k]["label"]) for k in looks], preselect=0)
        self.params["key"] = looks[choice] if choice >= 0 else "kodaches"
        self.preset()
        self.setup_guide()
        self.install_retrying(APPS_PACK)
        use_weather()
        if self.params.get("auto") != "1":
            more = [s for s in SERVICES if not addon_state(s[0])[0]]
            picked = xbmcgui.Dialog().multiselect(L(30151), [s[1] for s in more]) if more else []
            for i in picked or []:
                install_addon(more[i][0])
            use_weather()
        addon().setSetting("setup_done", "true")
        self.notify(L(30214))

    def maintenance(self):
        """Clears what Kodi piles up: downloaded add-on packages, temporary files and Kodaches' caches."""
        freed = 0
        targets = [xbmcvfs.translatePath("special://home/addons/packages"),
                   os.path.join(xbmcvfs.translatePath("special://temp"), "archive_cache")]
        for folder in targets:
            for name in (os.listdir(folder) if os.path.isdir(folder) else []):
                path = os.path.join(folder, name)
                try:
                    size = os.path.getsize(path) if os.path.isfile(path) else sum(
                        os.path.getsize(os.path.join(r, f)) for r, _d, fs in os.walk(path) for f in fs)
                    shutil.rmtree(path) if os.path.isdir(path) else os.remove(path)
                    freed += size
                except OSError:
                    pass
        for name in ("catalog.json", "games-today.json"):
            path = os.path.join(profile_dir(), name)
            if os.path.exists(path):
                freed += os.path.getsize(path)
                os.remove(path)
        xbmcgui.Dialog().ok("Kodaches", L(30149) % ("%.1f MB" % (freed / 1e6)))

    def updates(self):
        # Kodi's own updater: re-reads every enabled repository, including the Kodaches one.
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")
        self.notify(L(30156))

    def open_settings(self):
        addon().openSettings()

    def preset(self):
        key = self.params["key"]

        def rpc(method, params):
            reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                                "params": params})))
            if "error" in reply:
                raise RuntimeError(reply["error"].get("message", "error"))
            return reply.get("result")

        def wait_for_skin(skin_id):
            monitor = xbmc.Monitor()
            for _ in range(240):  # the viewer confirms the install, then Kodi downloads it
                if xbmc.getCondVisibility("System.HasAddon(%s)" % skin_id):
                    return True
                if monitor.waitForAbort(0.5):
                    return False
            return False

        def prepare(skin):
            if skin == arctic.SKIN:
                write_arctic_menu()

        report = presets.apply(key, rpc, xbmc.executebuiltin, L,
                               lambda sid: bool(xbmc.getCondVisibility("System.HasAddon(%s)" % sid)), wait_for_skin,
                               install=self.install_retrying, prepare=prepare)
        addon().setSetting("preset", key)
        failed = [r for r in report if not r[1]]
        log("preset %s: %s" % (key, report))
        xbmcgui.Dialog().ok("Kodaches", L(30210) % L(presets.PRESETS[key]["label"]) +
                            ("\n" + "\n".join("%s: %s" % (r[0], r[2]) for r in failed) if failed else ""))

    def language(self):
        choice = xbmcgui.Dialog().select(L(30146), ["English", "Deutsch"])
        if choice < 0:
            return
        lang = ["resource.language.en_gb", "resource.language.de_de"][choice]
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % lang):
            xbmc.executebuiltin("InstallAddon(%s)" % lang)
        xbmc.executebuiltin("SetGUILanguage(%s)" % lang)


ROUTES = {
    None: Plugin.root, "live": Plugin.live, "all": Plugin.all, "section": Plugin.section,
    "section_all": Plugin.section_all, "subfolder": Plugin.subfolder, "play": Plugin.play, "fav": Plugin.fav,
    "favorites": Plugin.favorites, "recent": Plugin.recent, "refresh": Plugin.refresh, "sports": Plugin.sports,
    "league": Plugin.league, "event": Plugin.event, "movies": Plugin.movies, "films": Plugin.films,
    "film_search": Plugin.film_search, "play_film": Plugin.play_film, "search": Plugin.search,
    "music": Plugin.music, "kodi_music": Plugin.kodi_music, "apps": Plugin.apps, "settings": Plugin.settings,
    "updates": Plugin.updates, "open_settings": Plugin.open_settings, "preset": Plugin.preset,
    "language": Plugin.language, "services": Plugin.services, "install": Plugin.install, "widget": Plugin.widget,
    "setup": Plugin.setup, "addon_settings": Plugin.addon_settings, "open_music": Plugin.open_music,
    "open_weather": Plugin.open_weather, "run_addon": Plugin.run_addon,
    "tvguide": Plugin.tvguide, "rebuild_guide": Plugin.rebuild_guide, "maintenance": Plugin.maintenance, "cleanup": Plugin.cleanup,
}

# Routes that do something instead of listing a folder. Opened as a folder (a favourite, a launcher,
# RunAddon), Kodi waits for a listing that never comes, so they always close the directory.
ACTIONS = {"fav", "refresh", "event", "apps", "kodi_music", "updates", "open_settings", "preset", "language",
           "install", "setup", "maintenance", "cleanup", "addon_settings", "tvguide", "rebuild_guide",
           "open_music", "open_weather", "run_addon"}


def run(argv=None):
    argv = argv or sys.argv
    plugin = Plugin(argv)
    mode = plugin.params.get("mode")
    if mode not in ROUTES:
        log("unknown mode %s" % mode, xbmc.LOGWARNING)
        return xbmcplugin.endOfDirectory(plugin.handle, succeeded=False)
    try:
        ROUTES[mode](plugin)
    except SourceError as exc:
        log("source error in %s: %s" % (mode, exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Kodaches", L(30201) % exc, xbmcgui.NOTIFICATION_ERROR, 6000)
        if plugin.handle >= 0 and mode not in ACTIONS:
            if mode in ("play", "play_film"):
                xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())
            else:
                xbmcplugin.endOfDirectory(plugin.handle, succeeded=False)
    finally:
        if mode in ACTIONS and plugin.handle >= 0:
            xbmcplugin.endOfDirectory(plugin.handle, succeeded=False, updateListing=False, cacheToDisc=False)
