"""
The Modern look: Kodaches on Arctic Horizon 2 (jurialmunkey's skin, installed from his repository through the
Kodaches repository). Arctic Horizon 2 builds its home screen with Skin Shortcuts, which reads the viewer's own menu
files before the skin's defaults. Kodaches writes those files: a menu entry per section, rows under each entry.
No Kodi imports (unit-tested).

Skin Shortcuts rules this relies on (script.skinshortcuts 2.0.3, read from its source):
  - the skin sets <doNotShareMenu/>, so file names start with the skin id: skin.arctic.horizon.2-mainmenu.DATA.xml
  - an entry's id comes from its label (spaces removed, lower case), not from <defaultID>; its rows are the group
    "<id>.1", stored as skin.arctic.horizon.2-<id>-1.DATA.xml; a row shows the folder its action opens
  - row settings live in skin.arctic.horizon.2.properties: JSON [[group, row id, property, value], ...]
  - the menu is rebuilt only when skin.arctic.horizon.2.hash is gone (new files alone do not count as a change)
"""

import hashlib
import json
import re
from xml.sax.saxutils import escape

SKIN = "skin.arctic.horizon.2"
PLUGIN = "plugin://plugin.video.kodaches/"
HASH_FILE = SKIN + ".hash"
PROPERTIES_FILE = SKIN + ".properties"


def icon(name):
    return "special://skin/extras/icons/%s.png" % name


def folder(query):
    return "ActivateWindow(Videos,%s?%s,return)" % (PLUGIN, query)


def row(label, widget, aspect="Square"):
    return (label, PLUGIN + "?mode=widget&w=" + widget, aspect)


# (label, icon, action, visible condition or None, rows). Labels are plain words: the id is derived from them, and
# Skin Shortcuts makes ids unique by adding "--0", so no two labels may be the same.
# Library entries use Kodi's own strings (342 Movies, 20343 TV shows ...) and keep the skin's own rows.
MENU = [
    ("Live TV", icon("livetv"), folder("mode=live"), None,
     [row("Your Favorites", "favorites"), row("Recently Watched", "recent"), row("German TV", "german_top"),
      row("Free Channels", "fast")]),
    ("TV Guide", icon("tvguide"), "RunPlugin(%s?mode=tvguide)" % PLUGIN, None, []),
    ("News", icon("globe"), folder("mode=section&key=world"), None,
     [row("World News", "world_news"), row("US News", "us_news")]),
    ("Sports", icon("trophy"), folder("mode=sports"), None,
     [row("Games Today", "games_today", "Landscape"), row("Sports Channels", "sports_channels")]),
    ("Kids", icon("children"), folder("mode=section&key=kids"), None,
     [row("Kids Channels", "kids"), row("Kids Apps", "kids_apps")]),
    ("342", icon("film"), "ActivateWindow(Videos,MovieTitles,return)", "Library.HasContent(Movies)", None),
    ("20343", icon("tv"), "ActivateWindow(Videos,TVShowTitles,return)", "Library.HasContent(TVShows)", None),
    ("Free Movies", icon("clapperboard"), folder("mode=movies"), None, [row("Classic Films", "films", "Poster")]),
    ("Streaming Apps", icon("video-addons"), folder("mode=services"), None, [row("Apps", "services")]),
    ("2", icon("songs"), "ActivateWindow(Music)", None, None),
    ("3", icon("video"), "ActivateWindow(Videos)", None, None),
    ("Favorite Channels", icon("favourites"), folder("mode=favorites"), None, []),
    ("Search", icon("search"), folder("mode=search"), None, []),
]


def label_id(label):
    """Skin Shortcuts' id for a plain-word label ("Live TV" -> "livetv")."""
    return re.sub(r"[^a-z0-9]", "", label.lower())


def _shortcut(label, icon_path, action, visible=None, label2="Kodaches"):
    parts = ["    <shortcut>", "        <label>%s</label>" % escape(label),
             "        <label2>%s</label2>" % escape(label2), "        <icon>%s</icon>" % escape(icon_path),
             "        <thumb />", "        <action>%s</action>" % escape(action)]
    if visible:
        parts.append("        <visible>%s</visible>" % escape(visible))
    return "\n".join(parts + ["    </shortcut>"])


def _data(shortcuts):
    return "<?xml version='1.0' encoding='UTF-8'?>\n<shortcuts>\n%s\n</shortcuts>\n" % "\n".join(shortcuts)


def files():
    """{file name in addon_data/script.skinshortcuts: content} for the Kodaches menu on Arctic Horizon 2."""
    out = {SKIN + "-mainmenu.DATA.xml": _data([_shortcut(label, ic, action, visible)
                                                for label, ic, action, visible, _rows in MENU])}
    properties = []
    for label, _icon, _action, _visible, rows in MENU:
        if not rows:  # no rows, or a library entry that keeps the skin's own rows
            continue
        menu_id = label_id(label)
        out["%s-%s-1.DATA.xml" % (SKIN, menu_id)] = _data(
            [_shortcut(r_label, "", "ActivateWindow(Videos,%s,return)" % path, label2="")
             for r_label, path, _aspect in rows])
        for r_label, _path, aspect in rows:
            properties.append(["%s.1" % menu_id, label_id(r_label), "widgetAspect", aspect])
    out[PROPERTIES_FILE] = json.dumps(properties, indent=1) + "\n"
    return out


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def plan_writes(existing, written_before):
    """
    existing: {name: current content or None}; written_before: {name: digest Kodaches wrote last time}.
    Returns (to_write {name: content}, kept [names the viewer changed]). A file is (re)written only if it is missing
    or still exactly what Kodaches wrote, so a menu the viewer edited in the skin is never overwritten.
    """
    to_write, kept = {}, []
    for name, content in files().items():
        current = existing.get(name)
        if current is None or written_before.get(name) == digest(current):
            if current != content:
                to_write[name] = content
        else:
            kept.append(name)
    return to_write, kept
