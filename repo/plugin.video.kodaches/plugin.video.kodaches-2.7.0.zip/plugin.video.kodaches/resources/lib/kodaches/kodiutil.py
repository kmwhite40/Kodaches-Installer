"""Kodi helpers: settings, strings, and what Kodaches keeps on this device (catalog cache, favorites, history)."""

import json
import os
import tempfile
import time
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import arctic, sources
from .health import pick_variant  # (kodiutil.health() is the stored check results)

ADDON_ID = "plugin.video.kodaches"
PLAYING_PROPERTY = "kodaches.playing"
RECENT_LIMIT = 30
FAILED_FOR = 24 * 3600  # a feed that failed is tried last for a day
HEALTH_REQUEST = "kodaches.health.request"
HEALTH_STATUS = "kodaches.health.status"
GUIDE_REQUEST = "kodaches.guide.request"


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def stream_item(name, url):
    """
    (ListItem, path Kodi will play) for a live feed. DASH (BBC) needs InputStream Adaptive; for HLS it stays opt-in
    (it crashed Kodi on some German streams), and Kodi's own player gets one rendition instead of the master
    playlist, which it would open rendition by rendition before starting (health.pick_variant).
    """
    kind = sources.stream_kind(url)
    has_isa = xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)")
    isa = has_isa and (kind == "dash" or (kind == "hls" and addon().getSettingBool("use_isa")))
    path = url
    if kind == "hls" and not isa:
        try:
            path = pick_variant(url, user_agent=xbmc.getUserAgent()) or url
        except Exception as exc:  # never let preparing a stream stop it from playing
            log("rendition not picked for %s: %s" % (url.partition("|")[0], exc), xbmc.LOGWARNING)
    li = xbmcgui.ListItem(name, path=path)
    li.setContentLookup(False)
    li.setMimeType(sources.MIME_TYPES[kind])
    if isa:
        li.setProperty("inputstream", "inputstream.adaptive")
    return li, path


def L(string_id):
    return addon().getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Kodaches] %s" % message, level)


def profile_dir():
    path = xbmcvfs.translatePath(addon().getAddonInfo("profile"))
    os.makedirs(path, exist_ok=True)
    return path


def addon_dir():
    return xbmcvfs.translatePath(addon().getAddonInfo("path"))


def _path(name):
    return os.path.join(profile_dir(), name)


def read_json(name, default=None):
    try:
        with open(_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(name, data):
    # A unique temp file per write: home-screen rows load in parallel and would race on one name.
    fd, tmp = tempfile.mkstemp(prefix=name + ".", suffix=".tmp", dir=profile_dir())
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, _path(name))  # atomic, so readers never see half a file
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


# --- channel catalog ----------------------------------------------------------------

_memory = {}


def local_tags():
    try:
        with open(os.path.join(addon_dir(), "resources", "data", "local.json"), encoding="utf-8") as f:
            return json.load(f)["tags"]
    except (OSError, ValueError, KeyError):
        return {}


# Bumped when the way channels are built changes, so a device does not keep an older list for hours.
CATALOG_VERSION = 4
RETRY_INCOMPLETE = 15 * 60


def catalog(force=False, progress=None):
    """All channels, rebuilt from the public lists every few hours and kept on the device in between."""
    ttl = int(addon().getSetting("refresh_hours") or 6) * 3600
    now = time.time()
    hit = _memory.get("catalog")
    if hit and not force and now - hit[0] < ttl:
        return hit[1]
    disk = None if force else read_json("catalog.json")
    if disk and now - disk.get("at", 0) < ttl and disk.get("version") == CATALOG_VERSION:
        _memory["catalog"] = (disk["at"], disk["channels"])
        return disk["channels"]
    if progress:
        progress()
    try:
        channels, errors = sources.load(local_tags=local_tags())
    except sources.SourceError:
        if disk:  # offline or iptv-org down: an old list beats none
            kept = [c for c in disk["channels"] if not sources.KODI_REFUSED_RE.search(c["url"])]
            _memory["catalog"] = (now, kept)
            return kept
        raise
    for err in errors:
        log("list skipped: %s" % err, xbmc.LOGWARNING)
    # A list was missing (Local or Sports could be empty): try again in 15 minutes, not after the full refresh time.
    at = now - ttl + RETRY_INCOMPLETE if errors else now
    write_json("catalog.json", {"version": CATALOG_VERSION, "at": at, "channels": channels})
    _memory["catalog"] = (at, channels)
    return channels


# --- favorites, recently watched, failed feeds ------------------------------------------

def favorites():
    return read_json("favorites.json", []) or []


def set_favorite(channel_id, value):
    favs = [f for f in favorites() if f != channel_id]
    if value:
        favs.append(channel_id)
    write_json("favorites.json", favs)


def recent():
    return read_json("recent.json", []) or []


def add_recent(channel_id):
    write_json("recent.json", ([channel_id] + [r for r in recent() if r != channel_id])[:RECENT_LIMIT])


def failed_urls():
    now = time.time()
    return {u: t for u, t in (read_json("failed.json", {}) or {}).items() if now - t < FAILED_FOR}


def mark_failed(url):
    failed = failed_urls()
    failed[url] = time.time()
    write_json("failed.json", failed)


def clear_failed(url):
    failed = failed_urls()
    if failed.pop(url, None) is not None:
        write_json("failed.json", failed)


# --- background health checks (service.py) ---------------------------------------------

def health():
    """{url: [alive, seconds to first media, checked at]} from the last checks."""
    return read_json("health.json", {}) or {}


def save_health(results):
    write_json("health.json", results)


def health_ttl():
    return int(addon().getSetting("refresh_hours") or 6) * 3600


def unavailable_urls():
    """Feeds not to offer first: failed while playing today, or found dead by the last health check."""
    out = failed_urls()
    now = time.time()
    for url, (alive, _secs, at) in health().items():
        if not alive and now - at < max(health_ttl(), FAILED_FOR):
            out.setdefault(url, at)
    return out


def feed_speeds():
    return {url: secs for url, (alive, secs, _at) in health().items() if alive}


def addon_state(addon_id):
    """(installed, enabled). System.HasAddon is false for installed-but-disabled add-ons, such as the
    IPTV Simple client Kodi ships disabled, so ask JSON-RPC instead."""
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled"]}})))
    details = (reply.get("result") or {}).get("addon")
    return (True, bool(details.get("enabled"))) if details else (False, False)


def enable_addon(addon_id):
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                    "params": {"addonid": addon_id, "enabled": True}}))


def in_repository(addon_id):
    """True when an enabled repository offers the add-on (Kodi only knows after it has read the repository)."""
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddons",
                                                       "params": {"installed": False}})))
    return any(a.get("addonid") == addon_id for a in (reply.get("result") or {}).get("addons") or [])


def write_arctic_menu():
    """
    The Modern look's home screen: Kodaches' menu and rows as Skin Shortcuts files for Arctic Horizon 2. Files the
    viewer changed in the skin since Kodaches wrote them are left alone. Returns (written names, kept names).
    """
    folder = xbmcvfs.translatePath("special://profile/addon_data/script.skinshortcuts")
    os.makedirs(folder, exist_ok=True)
    record = read_json("arctic-menu.json", {}) or {}
    existing = {}
    for name in arctic.files():
        path = os.path.join(folder, name)
        existing[name] = open(path, encoding="utf-8").read() if os.path.exists(path) else None
    to_write, kept = arctic.plan_writes(existing, record)
    for name, content in to_write.items():
        fd, tmp = tempfile.mkstemp(dir=folder, suffix=".part")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp, os.path.join(folder, name))
        record[name] = arctic.digest(content)
    if to_write:  # Skin Shortcuts rebuilds the menu only when its hash file is gone
        hash_file = os.path.join(folder, arctic.HASH_FILE)
        if os.path.exists(hash_file):
            os.remove(hash_file)
    write_json("arctic-menu.json", record)
    log("Modern look menu: wrote %s, kept %s" % (sorted(to_write), kept))
    return sorted(to_write), kept


SLYGUY_REPOSITORY = "repository.slyguy"
NEEDS_SLYGUY = ("slyguy.", "script.kodaches.apps")


def install_addon(addon_id, wait_secs=90):
    """
    Kodi's own installer (it asks the viewer to confirm). On a fresh Kodi the repositories may not have been read
    yet, and InstallAddon then does nothing, so refresh them first and wait until the add-on is listed.
    SlyGuy's add-ons depend on SlyGuy's repository add-on, and Kodi never installs a repository as a dependency
    ("has type ADDON_REPOSITORY and will not install"), so that one is installed first, on its own.
    """
    if addon_id.startswith(NEEDS_SLYGUY) and not addon_state(SLYGUY_REPOSITORY)[0]:
        install_addon(SLYGUY_REPOSITORY, wait_secs)
    if not in_repository(addon_id):
        log("install %s: not listed by any repository yet, refreshing repositories" % addon_id)
        xbmc.executebuiltin("UpdateAddonRepos")
        monitor = xbmc.Monitor()
        waited = 0
        while not in_repository(addon_id) and waited < wait_secs and not monitor.waitForAbort(1):
            waited += 1
        log("install %s: listed=%s after %ds" % (addon_id, in_repository(addon_id), waited))
    xbmc.executebuiltin("InstallAddon(%s)" % addon_id, True)
    installed = addon_state(addon_id)[0]
    log("install %s: installed=%s" % (addon_id, installed))
    return installed


def use_weather(addon_id="weather.multi"):
    """Makes an installed weather add-on Kodi's weather provider, unless the viewer already picked one."""
    if not addon_state(addon_id)[0]:
        return False
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
                                                       "params": {"setting": "weather.addon"}})))
    if (reply.get("result") or {}).get("value"):
        return True
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                                    "params": {"setting": "weather.addon", "value": addon_id}}))
    return True


_now_next = {}


def now_next():
    """{channel name: (now title, next title)} from Kodi's TV guide (IPTV Simple), cached for a minute."""
    hit = _now_next.get("data")
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    data = {}
    if xbmc.getCondVisibility("System.HasPVRAddon"):
        try:
            reply = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "PVR.GetChannels",
                "params": {"channelgroupid": "alltv", "properties": ["broadcastnow", "broadcastnext"]}})))
            for ch in (reply.get("result") or {}).get("channels") or []:
                now = (ch.get("broadcastnow") or {}).get("title") or ""
                nxt = (ch.get("broadcastnext") or {}).get("title") or ""
                if now or nxt:
                    data[ch.get("label", "")] = (now, nxt)
        except (ValueError, TypeError):
            pass
    if data:  # an empty answer usually means the TV section is still loading: ask again next time
        _now_next["data"] = (time.time(), data)
    return data


def clock(iso):
    """ISO timestamp -> local "HH:MM" in Kodi's region format."""
    try:
        when = datetime.fromisoformat((iso or "").replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    return when.strftime(xbmc.getRegion("time").replace(":%S", ""))


def day_and_clock(iso):
    try:
        when = datetime.fromisoformat((iso or "").replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    return when.strftime("%a ") + when.strftime(xbmc.getRegion("time").replace(":%S", ""))
