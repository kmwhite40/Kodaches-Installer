"""
Background service.

1. Failover: the plugin leaves the channel's feeds (working, fastest first) in a Home-window property.
   When a feed fails to play, the service marks it failed for a day and plays the channel's next feed.
2. Clean-up: every few hours (and on request from the menu) it checks the channel feeds in the
   background, most-watched first, and records which work and how fast. Channels with no working
   feed disappear from the menus; working feeds are tried fastest first. It pauses while video plays,
   so it never competes with what is on screen.
"""

import json
import threading
import time

import xbmc
import xbmcgui

from . import catalog, health
from .kodiutil import (HEALTH_REQUEST, HEALTH_STATUS, L, PLAYING_PROPERTY, catalog as load_catalog, clear_failed,
                       favorites, health as stored_health, health_ttl, log, mark_failed, read_json, recent,
                       save_health, write_json)

CHECK_WORKERS = 6
SAVE_EVERY = 150


class Player(xbmc.Player):
    def _pending(self):
        raw = xbmcgui.Window(10000).getProperty(PLAYING_PROPERTY)
        return json.loads(raw) if raw else None

    def onAVStarted(self):
        info = self._pending()
        if not info:
            return  # films, or something not from Kodaches
        try:
            playing = self.getPlayingFile()
        except RuntimeError:
            return
        current = info["urls"][info["index"]]
        if playing == current or playing.split("|", 1)[0] == current.split("|", 1)[0]:
            clear_failed(current)
            xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)

    def onPlayBackError(self):
        info = self._pending()
        if not info:
            return
        failed = info["urls"][info["index"]]
        mark_failed(failed)
        log("feed failed for %s: %s" % (info["name"], failed.split("|", 1)[0]), xbmc.LOGWARNING)
        info["index"] += 1
        if info["index"] >= len(info["urls"]):
            xbmcgui.Window(10000).clearProperty(PLAYING_PROPERTY)
            xbmcgui.Dialog().notification("Kodaches", L(30202), xbmcgui.NOTIFICATION_WARNING, 5000)
            return
        xbmcgui.Window(10000).setProperty(PLAYING_PROPERTY, json.dumps(info))
        xbmcgui.Dialog().notification("Kodaches", L(30211) % info["name"], xbmcgui.NOTIFICATION_INFO, 3000)
        li = xbmcgui.ListItem(info["name"], path=info["urls"][info["index"]])
        li.setContentLookup(False)
        li.setMimeType("application/vnd.apple.mpegurl" if info.get("kind") == "hls" else "video/mp2t")
        self.play(info["urls"][info["index"]], li)


class Cleanup:
    def __init__(self, monitor, player):
        self.monitor = monitor
        self.player = player

    def due(self):
        last = (read_json("health-run.json", {}) or {}).get("finished", 0)
        return time.time() - last >= health_ttl()

    def wait_while_playing(self):
        while self.player.isPlayingVideo() and not self.monitor.abortRequested():
            self.monitor.waitForAbort(5)

    def run(self, visible):
        window = xbmcgui.Window(10000)
        channels = load_catalog()
        urls = catalog.check_order(channels, first_ids=favorites() + recent())
        results = stored_health()
        now = time.time()
        # Only feeds not checked recently; a manual clean-up re-checks everything.
        todo = urls if visible else [u for u in urls if now - results.get(u, [0, 0, 0])[2] >= health_ttl()]
        if not todo:
            write_json("health-run.json", {"finished": time.time()})
            return
        progress = None
        if visible:
            progress = xbmcgui.DialogProgressBG()
            progress.create("Kodaches", L(30160))
        done, lock = [0], threading.Lock()

        def on_result(url, result):
            with lock:
                results[url] = [result[0], round(result[1], 2), time.time()]
                done[0] += 1
                if done[0] % SAVE_EVERY == 0:
                    save_health(dict(results))
                if progress:
                    progress.update(int(100 * done[0] / len(todo)), "Kodaches", L(30161) % (done[0], len(todo)))
            window.setProperty(HEALTH_STATUS, "%d/%d" % (done[0], len(todo)))

        log("checking %d feeds" % len(todo))
        started = time.time()
        health.check_all(todo, workers=CHECK_WORKERS, per_host=2, timeout=6,
                         should_stop=self.monitor.abortRequested, on_result=on_result,
                         before=self.wait_while_playing)
        save_health(results)
        write_json("health-run.json", {"finished": time.time()})
        window.clearProperty(HEALTH_STATUS)
        dead = sum(1 for c in channels if not catalog.available(
            c, {u: 1 for u, r in results.items() if not r[0]}))
        log("checked %d feeds in %ds; %d channels without a working feed" % (done[0], time.time() - started, dead))
        if progress:
            progress.close()
            xbmcgui.Dialog().notification("Kodaches", L(30162) % (len(channels) - dead, dead),
                                          xbmcgui.NOTIFICATION_INFO, 6000)

    def loop(self):
        if self.monitor.waitForAbort(60):  # let Kodi finish starting up first
            return
        while not self.monitor.abortRequested():
            window = xbmcgui.Window(10000)
            requested = window.getProperty(HEALTH_REQUEST) == "1"
            if requested or self.due():
                window.clearProperty(HEALTH_REQUEST)
                try:
                    self.run(visible=requested)
                except Exception as exc:  # never let the clean-up take the service down
                    log("clean-up failed: %s" % exc, xbmc.LOGWARNING)
            if self.monitor.waitForAbort(10):
                break


def run():
    monitor = xbmc.Monitor()
    player = Player()
    log("service started")
    threading.Thread(target=Cleanup(monitor, player).loop, name="kodaches-cleanup", daemon=True).start()
    monitor.waitForAbort()
    log("service stopped")
