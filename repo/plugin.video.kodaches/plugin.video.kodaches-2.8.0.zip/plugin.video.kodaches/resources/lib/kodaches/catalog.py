"""
Menu sections over the channel catalog built by sources.py. Pure functions, no Kodi imports.
"""

from urllib.parse import urlsplit

# Section key -> (string id, predicate, how to split it one level down). Order is the menu order.
SECTIONS = [
    ("german", 30110, lambda c: "de" in c["lists"] or "deu" in c["lists"], "group"),
    ("us", 30111, lambda c: "us" in c["lists"], "group"),
    ("local", 30112, lambda c: any(f.startswith("local:") for f in c["flags"]), "local"),
    ("world", 30184, lambda c: "world" in c["flags"], "none"),
    ("sports", 30113, lambda c: "sports" in c["lists"] or c["group"] == "Sports", "country"),
    ("news", 30114, lambda c: "news" in c["lists"] or c["group"] in ("News", "Weather"), "country"),
    ("kids", 30115, lambda c: "kids" in c["lists"] or c["group"] in ("Kids", "Animation", "Family"), "country"),
    ("movies", 30116, lambda c: "movies" in c["lists"], "country"),
    ("series", 30120, lambda c: "series" in c["lists"], "country"),
    ("documentary", 30121, lambda c: "documentary" in c["lists"], "country"),
    ("music", 30117, lambda c: "music" in c["lists"], "country"),
    ("fast", 30118, lambda c: any(f.startswith("fast:") for f in c["flags"]), "fast"),
]
SECTION_KEYS = [s[0] for s in SECTIONS]

FLAG_LABELS = {
    "local:dfw": "Dallas - Fort Worth",
    "local:us-tx": "Texas",
    "fast:pluto": "Pluto TV",
    "fast:samsung": "Samsung TV Plus",
    "fast:plex": "Plex",
    "fast:roku": "The Roku Channel",
    "fast:tubi": "Tubi",
    "fast:xumo": "Xumo Play",
    "fast:lg": "LG Channels",
    "fast:stirr": "Stirr",
}
COUNTRY_NAMES = {
    "us": "United States", "de": "Germany", "at": "Austria", "ch": "Switzerland", "gb": "United Kingdom",
    "uk": "United Kingdom", "ca": "Canada", "fr": "France", "it": "Italy", "es": "Spain", "nl": "Netherlands",
    "mx": "Mexico", "br": "Brazil", "ar": "Argentina", "au": "Australia", "in": "India", "tr": "Turkey",
    "pl": "Poland", "pt": "Portugal", "ru": "Russia", "ua": "Ukraine", "jp": "Japan", "kr": "South Korea",
    "cn": "China", "ae": "United Arab Emirates", "sa": "Saudi Arabia", "eg": "Egypt", "za": "South Africa",
}


def _section(key):
    for s in SECTIONS:
        if s[0] == key:
            return s
    raise KeyError(key)


def section(channels, key):
    found = [c for c in channels if _section(key)[2](c)]
    if key == "world":  # the curated order (sources.WORLD_NEWS), not alphabetical
        found.sort(key=lambda c: c.get("world_rank", 99))
    return found


def section_counts(channels):
    return [(key, sid, sum(1 for c in channels if pred(c))) for key, sid, pred, _split in SECTIONS]


def _keys(channel, split):
    if split == "group":
        return [channel["group"] or "General"]
    if split == "country":
        return [channel["country"] or "other"]
    if split == "none":
        return ["all"]
    return [f for f in channel["flags"] if f.startswith(split + ":")]


def _label(value, split):
    if split == "country":
        return "Other" if value == "other" else COUNTRY_NAMES.get(value, value.upper())
    return FLAG_LABELS.get(value, value.split(":", 1)[-1]) if ":" in value else value


def subfolders(channels, key):
    """[(value, label, count)] one level down, biggest first; for country splits the U.S. and Germany lead."""
    split = _section(key)[3]
    counts = {}
    for c in channels:
        for value in _keys(c, split):
            counts[value] = counts.get(value, 0) + 1
    first = {"us": 0, "de": 1, "at": 2, "ch": 3} if split == "country" else {}
    return sorted(((v, _label(v, split), n) for v, n in counts.items()),
                  key=lambda t: (first.get(t[0], 9), -t[2], t[1]))


def in_subfolder(channels, key, value):
    split = _section(key)[3]
    return [c for c in channels if value in _keys(c, split)]


def by_ids(channels, ids):
    index = {c["id"]: c for c in channels}
    return [index[i] for i in ids if i in index]


def find(channels, query, limit=60):
    """Channel-name search: names starting with the query first, then names containing it."""
    q = query.strip().lower()
    if not q:
        return []
    starts = [c for c in channels if c["name"].lower().startswith(q)]
    contains = [c for c in channels if q in c["name"].lower() and c not in starts]
    return (starts + contains)[:limit]


def sort_channels(channels):
    return sorted(channels, key=lambda c: c["name"].lower())


def playable_urls(channel, failed, speeds=None):
    """Feeds to try: working ones first (fastest first when speeds are known), failed ones last."""
    urls = [channel["url"]] + channel.get("alternates", [])
    speeds = speeds or {}
    good = sorted((u for u in urls if u not in failed), key=lambda u: speeds.get(u, 99))
    return good + [u for u in urls if u in failed]


def check_order(channels, first_ids=()):
    """
    Feeds for the background check, most-watched first: favorites/recent, then local, German, U.S. and
    sports, then the rest. Backup feeds are included so failover knows which ones work.
    """
    first = set(first_ids)
    rank = {"local": 1, "german": 2, "us": 3, "sports": 4}

    def score(c):
        if c["id"] in first:
            return 0
        for key, r in rank.items():
            if _section(key)[2](c):
                return r
        return 9
    urls, seen = [], set()
    for c in sorted(channels, key=score):
        for u in [c["url"]] + c.get("alternates", []):
            if u not in seen:
                seen.add(u)
                urls.append(u)
    return urls


def available(channel, failed):
    return any(u not in failed for u in [channel["url"]] + channel.get("alternates", []))


def only_on_hosts(channels, hosts):
    """How many channels have every feed on these hosts (they go when the hosts are blocked)."""
    def host(url):
        return (urlsplit(url.partition("|")[0]).hostname or "").lower()
    return sum(1 for c in channels if all(host(u) in hosts for u in [c["url"]] + c.get("alternates", [])))
