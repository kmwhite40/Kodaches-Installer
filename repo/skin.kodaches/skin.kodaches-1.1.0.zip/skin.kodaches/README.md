# Kodaches skin (`skin.kodaches`)

Based on **Estuary by Team Kodi** (Kodi 21 "Omega", `xbmc.gui` 5.17.0). See `LICENSE.txt`:
code GPL-2.0, artwork CC BY-SA 4.0.

What differs from Estuary:

| Area | Change |
|---|---|
| `addon.xml` | id `skin.kodaches`, name/provider "Kodaches", version 1.0.0 |
| `colors/defaults.xml` | default theme: navy `#0A1022` backgrounds, teal `#00B4BE` focus, amber `#FFB02E` selection |
| `xml/Home.xml` | main menu: Live TV, German TV, U.S. TV, Local, Sports, Movies, Streaming Apps, Search, Favorites, Add-ons; widget rows from `plugin://plugin.video.kodaches/?mode=widget&w=<name>` |
| `xml/Variables.xml` | home background falls back to the Kodaches fanart |
| `media/kodaches/` | top-bar wordmark and side-menu icons (loose PNGs next to Estuary's `Textures.xbt`) |
| `extras/backgrounds/kodaches-fanart.jpg`, `resources/` | Kodaches add-on fanart/icon |
| `fonts/` | real font files instead of Debian's symlinks |

Everything else (dialogs, views, OSD, settings) is Estuary unchanged.

Widget rows hide themselves when the plugin returns no items; if every row of a menu entry
is empty, an "Open <section>" button is shown instead.

Screenshots in a real Kodi 21: `python3 tests/integration/skin_screens.py` (needs Docker and
the `kodaches-kodi-test` image); output in `tests/integration/work-skin/`.
