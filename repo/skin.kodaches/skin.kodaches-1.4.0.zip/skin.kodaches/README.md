# Kodaches Aurora skin (`skin.kodaches`)

Based on **Estuary by Team Kodi** (Kodi 21 "Omega", `xbmc.gui` 5.17.0). See `LICENSE.txt`:
code GPL-2.0, artwork CC BY-SA 4.0.

What differs from Estuary:

| Area | Change |
|---|---|
| `addon.xml` | id `skin.kodaches`, name/provider "Kodaches", version 1.4.0 |
| `colors/defaults.xml` | Aurora palette: ink navy backgrounds, teal focus (white text on it at 3.4:1 contrast), warm amber selection |
| `xml/Home.xml` | atmospheric backdrop, glass-focus navigation and compact remote-first menu; Live TV, German TV, U.S. TV, Local, Sports, Movies, Streaming Apps, Search, Favorites and Kodi sections; widget rows from `plugin://plugin.video.kodaches/?mode=widget&w=<name>` |
| `xml/Variables.xml` | home background falls back to the Kodaches fanart |
| `media/kodaches/` | top-bar wordmark, menu icons and generated home UI textures (loose PNGs next to Estuary's `Textures.xbt`) |
| `extras/backgrounds/kodaches-bg.jpg`, `media/kodaches/ui/`, `resources/` | Aurora wallpaper, home UI textures and add-on fanart/icon |
| `fonts/` | real font files instead of Debian's symlinks |

Everything else (dialogs, views, OSD, settings) follows Estuary's familiar Kodi layouts.

The generated backdrop, menu scrim and focus surface can be regenerated with:

```sh
python scripts/make_art.py <temporary-output-directory> kodi/skin.kodaches
```

The command also writes the add-on icon and fanart into the first directory; it does not change them
in the skin folder.

Widget rows hide themselves when the plugin returns no items; if every row of a menu entry
is empty, an "Open <section>" button is shown instead.

Screenshots in a real Kodi 21: `python3 tests/integration/skin_screens.py` (needs Docker and
the `kodaches-kodi-test` image); output in `tests/integration/work-skin/`.
