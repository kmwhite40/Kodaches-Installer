"""Kodaches Apps has no code: installing it makes Kodi install the free apps it lists as dependencies."""
