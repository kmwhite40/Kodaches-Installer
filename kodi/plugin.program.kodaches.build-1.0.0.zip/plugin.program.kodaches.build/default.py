from resources.lib.kodaches_build import run

run(ask=True)
