from resources.lib.kodaches_build import first_start

first_start()
