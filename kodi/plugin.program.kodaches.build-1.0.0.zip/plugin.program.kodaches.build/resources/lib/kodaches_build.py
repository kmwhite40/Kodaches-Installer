"""
Kodaches Build: one zip that installs the whole build.

Installing a zip cannot pull add-ons from a repository Kodi does not have yet, so this add-on carries the Kodaches
repository (resources/repository.kodaches.zip, added at build time), adds it, and then installs Kodaches *from* it
with Kodi's own installer. That keeps Kodaches and its skin (a dependency) updating themselves from the repository;
add-ons unpacked by hand have no repository of origin and never update. Kodaches' setup then does the rest
(skin, streaming settings, TV guide, the free apps).
"""

import json
import os
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.program.kodaches.build"
REPOSITORY = "repository.kodaches"
KODACHES = "plugin.video.kodaches"
SETUP = "RunPlugin(plugin://plugin.video.kodaches/?mode=setup&auto=1)"


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def L(string_id):
    return addon().getLocalizedString(string_id)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Kodaches Build] %s" % message, level)


def rpc(method, params=None):
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                        "params": params or {}})))
    return reply.get("result") or {}


def installed(addon_id):
    return bool(rpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]}).get("addon"))


def listed(addon_id):
    """True when an enabled repository offers the add-on (Kodi knows only after reading the repository)."""
    return any(a.get("addonid") == addon_id for a in rpc("Addons.GetAddons", {"installed": False}).get("addons") or [])


def profile_file(name):
    folder = xbmcvfs.translatePath(addon().getAddonInfo("profile"))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, name)


def wait_for(check, seconds, progress=None):
    monitor = xbmc.Monitor()
    for _ in range(seconds):
        if check():
            return True
        if monitor.waitForAbort(1) or (progress and progress.iscanceled()):
            return False
    return check()


def add_repository():
    """Unpacks the bundled repository add-on into Kodi's add-ons folder and enables it."""
    if not installed(REPOSITORY):
        bundled = os.path.join(xbmcvfs.translatePath(addon().getAddonInfo("path")), "resources", REPOSITORY + ".zip")
        target = xbmcvfs.translatePath("special://home/addons")
        with zipfile.ZipFile(bundled) as zf:
            for member in zf.namelist():
                parts = member.split("/")
                if parts[0] != REPOSITORY or ".." in parts:  # only the repository's own files
                    raise ValueError("unexpected file in the bundled repository: %s" % member)
            zf.extractall(target)
        xbmc.executebuiltin("UpdateLocalAddons", True)
        if not wait_for(lambda: installed(REPOSITORY), 30):
            return False
    rpc("Addons.SetAddonEnabled", {"addonid": REPOSITORY, "enabled": True})
    return True


def run(ask=True):
    if ask and not xbmcgui.Dialog().yesno(L(32000), L(32001)):
        log("declined")
        return False
    progress = xbmcgui.DialogProgress()
    progress.create("Kodaches", L(32002))
    try:
        if not add_repository():
            raise RuntimeError("the Kodaches repository did not register")
        if not installed(KODACHES):
            progress.update(30, L(32003))
            xbmc.executebuiltin("UpdateAddonRepos")
            if not wait_for(lambda: listed(KODACHES), 180, progress):
                progress.close()
                xbmcgui.Dialog().ok("Kodaches", L(32005))
                log("Kodaches not listed by any repository yet", xbmc.LOGWARNING)
                return False
            progress.update(60, L(32004))
            progress.close()  # Kodi shows its own "Add-on required ... download?" dialog
            xbmc.executebuiltin("InstallAddon(%s)" % KODACHES, True)
            if not wait_for(lambda: installed(KODACHES), 120):
                xbmcgui.Dialog().ok("Kodaches", L(32007))
                log("Kodaches not installed (declined or failed)", xbmc.LOGWARNING)
                return False
        else:
            progress.close()
    finally:
        progress.close()
    open(profile_file("done"), "w").close()
    xbmcgui.Dialog().notification("Kodaches", L(32006), xbmcgui.NOTIFICATION_INFO, 4000)
    log("Kodaches installed; starting the build setup")
    xbmc.executebuiltin(SETUP)
    return True


def first_start():
    """Right after the zip is installed (and at each Kodi start until it has run once): offer the build."""
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(5):
        return
    if os.path.exists(profile_file("asked")) or installed(KODACHES):
        return
    open(profile_file("asked"), "w").close()  # ask once; the program entry runs it again
    try:
        run(ask=True)
    except Exception as exc:  # never let the installer take Kodi's service start-up down
        log("build install failed: %s" % exc, xbmc.LOGERROR)
